﻿# Obtenir des informations sur la machine

$MachineInfo = Get-WmiObject Win32_OperatingSystem | Select-Object Caption, Version, ServicePackMajorVersion, OSArchitecture, CSName, WindowsDirectory, NumberOfUsers, BootDevice

$OSversion = $MachineInfo.Caption
$OSName = $MachineInfo.CSName
$OSArchi = $MachineInfo.OSArchitecture


$Date = Get-Date -U %d%m%Y
$Nomdufichier = "Audit_config_" + $OSName + "_" + $Date + ".txt"

$Nomdudossier = "AUDIT_CONF_" + $OSName + "_" + $Date

New-Item -ItemType Directory -Name $Nomdudossier

Set-Location $Nomdudossier

$columnOrder = "ID", "Point de contrôle", "Status de conformité"
$columnOrder_constat = "ID", "Point de contrôle", "Constat"


# fonction de révérence SID à partir SecPol
Function Reverse-SID ($chaineSID) {


 $chaineSID = $chaineSID -creplace '^[^\\]*=', ''
 $chaineSID = $chaineSID.replace("*", "")
 $chaineSID = $chaineSID.replace(" ", "")
 if ( $chaineSID -ne $null){
 $tableau = @()
 $tableau = $chaineSID.Split(",") 


 ForEach ($ligne in $tableau) { 
  $sid = $null
  if ($ligne -like "S-*") {
   if($reverseCommandExist -eq $true){
   $sid = Get-WSManInstance -ResourceURI "wmicimv2/Win32_SID" -SelectorSet @{SID="$ligne"}|Select-Object AccountName
   $sid = $sid.AccountName
   }
if ( $sid -eq $null) {
    $objSID = New-Object System.Security.Principal.SecurityIdentifier ("$ligne")
    $objUser = $objSID.Translate( [System.Security.Principal.NTAccount])
    $sid=$objUser.Value
    if ( $sid -eq $null){
    $objUser = New-Object System.Security.Principal.NTAccount("$ligne") 
    $strSID = $objUser.Translate([System.Security.Principal.SecurityIdentifier])
    $sid=$strSID.Value
}
   $outpuReverseSid += $sid + "|"

  }else{
   $outpuReverseSid += $ligne + "|"
  }
 }
 
 }
 return $outpuReverseSid
}else {
$outpuReverseSid += No One 
 return $outpuReverseSid

}
}

# convertir un Stringarray en une liste séparée par des virgules 
function StringArrayToList($StringArray) {
  if ($StringArray) {
    $Result = ""
    Foreach ($Value In $StringArray) {
      if ($Result -ne "") { $Result += "," }
      $Result += $Value
    }
    return $Result
  }
  else {
    return ""
  }
}


# Création des fichiers 
$fichier_secedit = "./Sec_" + "$OSName" + ".cfg"
secedit /export /cfg $fichier_secedit 
$fichier_gpo = "./gpo_" + "$OSName" + ".txt"
gpresult /r /V > $fichier_gpo
$fichier_gpo = "./gpo_" + "$OSName" + ".html"
gpresult /h $fichier_gpo /f | out-null


#informations sur les règles du pare-feu
Write-Host "================ Extraction des informations sur les règles du pare-feu ================"
$FichierCSV = "./regle-pare-feu_" + "$OSName" + ".csv"
$FirewallRules = Get-NetFirewallRule -PolicyStore "ActiveStore"

$FirewallRuleSet = @()
ForEach ($Rule In $FirewallRules) {
  # iterate throug rules
  # Retrieve addresses,
  $AdressFilter = $Rule | Get-NetFirewallAddressFilter
  # ports,
  $PortFilter = $Rule | Get-NetFirewallPortFilter
  # application,
  $ApplicationFilter = $Rule | Get-NetFirewallApplicationFilter
  # service,
  $ServiceFilter = $Rule | Get-NetFirewallServiceFilter
  # interface,
  $InterfaceFilter = $Rule | Get-NetFirewallInterfaceFilter
  # interfacetype
  $InterfaceTypeFilter = $Rule | Get-NetFirewallInterfaceTypeFilter
  # and security settings
  $SecurityFilter = $Rule | Get-NetFirewallSecurityFilter

  # generate sorted Hashtable
  $HashProps = [PSCustomObject]@{
    Name        = $Rule.Name
    DisplayName     = $Rule.DisplayName
    Description     = $Rule.Description
    Group        = $Rule.Group
    Enabled       = $Rule.Enabled
    Profile       = $Rule.Profile
    Platform      = StringArrayToList $Rule.Platform
    Direction      = $Rule.Direction
    Action       = $Rule.Action
    EdgeTraversalPolicy = $Rule.EdgeTraversalPolicy
    LooseSourceMapping = $Rule.LooseSourceMapping
    LocalOnlyMapping  = $Rule.LocalOnlyMapping
    Owner        = $Rule.Owner
    LocalAddress    = StringArrayToList $AdressFilter.LocalAddress
    RemoteAddress    = StringArrayToList $AdressFilter.RemoteAddress
    Protocol      = $PortFilter.Protocol
    LocalPort      = StringArrayToList $PortFilter.LocalPort
    RemotePort     = StringArrayToList $PortFilter.RemotePort
    IcmpType      = StringArrayToList $PortFilter.IcmpType
    DynamicTarget    = $PortFilter.DynamicTarget
    Program       = $ApplicationFilter.Program -Replace "$($ENV:SystemRoot.Replace("\","\\"))\\", "%SystemRoot%\" -Replace "$(${ENV:ProgramFiles(x86)}.Replace("\","\\").Replace("(","\(").Replace(")","\)"))\\", "%ProgramFiles(x86)%\" -Replace "$($ENV:ProgramFiles.Replace("\","\\"))\\", "%ProgramFiles%\"
    Package       = $ApplicationFilter.Package
    Service       = $ServiceFilter.Service
    InterfaceAlias   = StringArrayToList $InterfaceFilter.InterfaceAlias
    InterfaceType    = $InterfaceTypeFilter.InterfaceType
    LocalUser      = $SecurityFilter.LocalUser
    RemoteUser     = $SecurityFilter.RemoteUser
    RemoteMachine    = $SecurityFilter.RemoteMachine
    Authentication   = $SecurityFilter.Authentication
    Encryption     = $SecurityFilter.Encryption
    OverrideBlockRules = $SecurityFilter.OverrideBlockRules
  }

  # add to array with rules
  $FirewallRuleSet += $HashProps
}

$FirewallRuleSet | ConvertTo-CSV -NoTypeInformation  | Set-Content $FichierCSV
Write-Host "Les résultats sont sauvegardés dans $FichierCSV" -ForegroundColor Green


# Informations sur les Antivirus
Write-Host "================ Extraction des informations sur l'antivirus ================"

$resultsAV = @()
     $regPathList = "HKLM:\SOFTWARE\Wow6432Node\Microsoft\Windows\CurrentVersion\Uninstall",
                   "HKLM:SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall"


foreach($reg in $regPathList ) {
$key = Get-ChildItem $reg

            foreach($subkeyName in $key) {
$subkeyName = Get-ItemProperty -Path Registry::$subkeyName | Select  DisplayName, DisplayVersion, Comments
                    if(($subkeyName.DisplayName -match "antivirus" -or $subkeyName.DisplayName -match "EPP" -or  $subkeyName.DisplayName -match "EDR"  -or  $subkeyName.DisplayName -match "Security"   ) -or ($subkeyName.Comments -match "antivirus"-or $subkeyName.Comments  -match "EPP" -or  $subkeyName.Comments  -match "EDR"  -or  $subkeyName.Comments -match "Security" )) {
                        $resultObj = [PSCustomObject]@{
                            Product = $subkeyName.DisplayName
                            Version = $subkeyName.DisplayVersion
                            Comments =$subkeyName.Comments
                        }
                        

                        
                        $resultsAV += $resultObj

}
}
}

$FichierAntivirusCSV = "./Antivirus_" + "$OSName" + ".csv"


if ( $resultsAV.count -ge 1) { 

$resultsAV | Export-Csv -NoTypeInformation $FichierAntivirusCSV
Write-Host "Les résultats sont sauvegardés dans $FichierAntivirusCSV" -ForegroundColor Green
}else{
Write-Host "Aucun logiciel antivirus n'a été détecté, veuillez vérifier manuellement" -ForegroundColor Red
}


# Informations sur les partages 
Write-Host "================ Extraction des informations sur les partages ================"
$Fichierdepartages = "./PARTAGE_" + "$OSName" + ".csv"
  
function addShare {
  param([string]$NS, [string]$CS, [string]$US, [string]$TS, [string]$NDS)
  $d = New-Object PSObject
  $d | Add-Member -Name "Share Name" -MemberType NoteProperty -Value $NS
  $d | Add-Member -Name "Share Path "-MemberType NoteProperty -Value $CS
  $d | Add-Member -Name "Account Name "-MemberType NoteProperty -Value $US
  $d | Add-Member -Name "AccessControlType"-MemberType NoteProperty -Value $TS
  $d | Add-Member -Name "AccessRight"-MemberType NoteProperty -Value $NDS
  return $d
}
$tableauShare = @()
    
$listShare = Get-SmbShare 
  
  
foreach ( $share in $listShare) {
  
  
  $droits = Get-SmbShareAccess $share.name
  
  
  foreach ( $droit in $droits) {
  
  
    $tableauShare += addShare -NS $share.name -CS $share.path -US $droit.AccountName -TS $droit.AccessControlType -NDS $droit.AccessRight
  
  
  }
}

$tableauShare | ConvertTo-CSV -NoTypeInformation | Set-Content $Fichierdepartages
Write-Host "Les résultats sont sauvegardés dans $Fichierdepartages" -ForegroundColor Green


# Informations sur les AppData 
Write-Host "================ Extraction des informations de AppData ================"
  
$chemindeProfiles = (Get-ItemProperty -Path HKLM:\SOFTWARE\Microsoft\Windows' 'NT\CurrentVersion\ProfileList\).ProfilesDirectory
  
  
$profilactuel = Get-ChildItem $chemindeProfiles
  
$resultAPP = @()
$nomfichierAppData = "./APPDATA_" + "$OSName" + ".csv"
  
  
foreach ( $profil in $profilactuel) {
  
  $verifAppdata = Test-Path $chemindeProfiles\$profil\Appdata
  
  if ($verifAppdata -eq $true) {
  
    $resultat = Get-ChildItem $chemindeProfiles\$profil\Appdata -Recurse -Include *.bat, *.exe, *.ps1, *.ps1xml, *.PS2, *.PS2XML, *.psc1, *.PSC2, *.msi, *.py, *.pif, *.MSP , *.COM, *.SCR, *.hta, *.CPL, *.MSC, *.JAR, *.VB, *.VBS, *.VBE, *.JS, *.JSE, *.WS, *.wsf, *.wsc, *.wsh, *.msh, *.MSH1, *.MSH2, *.MSHXML, *.MSH1XML, *.MSH2XML, *.scf, *.REG, *.INF   | Select-Object Name, Directory, Fullname 
  
  foreach ($riskyfile in $resultat) {


  $resultApptemp = [PSCustomObject]@{
                            Name  = $riskyfile.Name
                            Directory = $riskyfile.Directory
                            Path = $riskyfile.Fullname
                            Profil= $profil.name
							
                        }

$resultAPP +=$resultApptemp


  }
  }
}
 

    $resulatCount = $resultAPP |Measure-Object 
    $resulatCount = $resulatCount.Count
  
  
  
    if ( $resulatCount -gt 0) {
      $resultAPP | Export-Csv -NoTypeInformation $nomfichierAppData
      Write-Host "Les résultats sont sauvegardés dans $nomfichierAppData" -ForegroundColor Green   
    }


# Obtenir des informations sur le système
Write-Host "================ Extraction des informations sur le système ================"
$Fichiersystème = "./systeminfo_" + "$OSName" + ".txt"
systeminfo > $Fichiersystème 
Write-Host "Les résultats sont sauvegardés dans $Fichiersystème" -ForegroundColor Green


#Liste des mises à jour 
Write-Host "================ Extraction des informations sur les mises à jour ================"
$Fichierupdate = "./systemUpdate- " + "$OSName" + ".html"
wmic qfe list brief /format:htable > $Fichierupdate
Write-Host "Les résultats sont sauvegardés dans $Fichierupdate" -ForegroundColor Green


#Les services installés
Write-Host "================ Extraction des informations sur les services installés ================"
$Fichierservice = "./Services_" + "$OSName" + ".csv"

Get-WmiObject win32_service | Select-Object Name, DisplayName, State, StartName, StartMode, PathName |Export-Csv $Fichierservice -NoTypeInformation
Write-Host "Les résultats sont sauvegardés dans $Fichierservice" -ForegroundColor Green

#Les tâches planifiées 
Write-Host "================ Extraction des informations sur les tâches planifiées ================"
$Fichiertache = "./Taches_planifiees_" + "$OSName" + ".csv"
$tabletache = Get-ScheduledTask |Select-Object -Property *
$resultTask= @()
foreach ($tache in $tabletache) {
$taskactions = Get-ScheduledTask $tache.Taskname |Select-Object -ExpandProperty Actions

 foreach ( $taskaction in $taskactions ) {


$resultTasktemp = [PSCustomObject]@{
                            Task_name = $tache.Taskname
                            Task_URI = $tache.URI
                            Task_state = $tache.State
                            Task_Author = $tache.Author
							Task_Description = $tache.Description
                            Task_action = $taskaction.Execute 
                            Task_action_Argument = $taskaction.Arguments
                            Task_Action_WorkingDirectory = $taskaction.WorkingDirectory
							
                        }

$resultTask += $resultTasktemp

 }
  }
  

$resultTask | Export-Csv -NoTypeInformation $Fichiertache
Write-Host "Les résultats sont sauvegardés dans $Fichiertache" -ForegroundColor Green

#Obtenir des informations sur les politiques
Write-Host "================ Extraction des informations sur les politiques ================"
$Fichiernetaccount = "./AccountsPolicy- " + "$OSName" + ".txt"
net accounts > $Fichiernetaccount
Write-Host "Les résultats sont sauvegardés dans $Fichiernetaccount" -ForegroundColor Green


#Obtenir la liste des ports ouverts 
Write-Host "================ Extraction des informations sur les ports ouverts ================"
$Fichierport = "./Ports_ouverts_" + "$OSName" + ".csv"

$listport = Get-NetTCPConnection | Select-Object @{Name="Adresse locale"; Expression={$_.LocalAddress}},
                                                 LocalPort,
                                                 State,
                                                 @{Name="Processus propriétaire"; Expression={$_.OwningProcess -replace '^.*\\\\([^\]]+)$', '$1'}}


$listport | Export-Csv -Path $Fichierport -NoTypeInformation -Encoding UTF8
Write-Host "Les résultats sont sauvegardés dans $Fichierport" -ForegroundColor Green

# les registres de démarrage
Write-Host "================ Extraction des informations sur les registres de démarrage ================"
$FichierDémarrage = "./Démarrage_" + "$OSName" + ".txt"
"HKCU:\Software\Microsoft\Windows\CurrentVersion\Run" >> $FichierDémarrage
Get-ItemProperty "HKCU:\Software\Microsoft\Windows\CurrentVersion\Run" |Select-Object * -exclude PSPath,PSParentPath, PSChildName, PSProvider, PSDrive >> $FichierDémarrage
"HKCU:\Software\Microsoft\Windows\CurrentVersion\RunOnce" >> $FichierDémarrage
Get-ItemProperty "HKCU:\Software\Microsoft\Windows\CurrentVersion\RunOnce" |Select-Object * -exclude PSPath,PSParentPath, PSChildName, PSProvider, PSDrive >> $FichierDémarrage
"HKCU:\Software\Microsoft\Windows NT\CurrentVersion\Windows" >> $FichierDémarrage
Get-ItemProperty "HKCU:\Software\Microsoft\Windows NT\CurrentVersion\Windows" |Select-Object * -exclude PSPath,PSParentPath, PSChildName, PSProvider, PSDrive >> $FichierDémarrage
"HKLM:\Software\Microsoft\Windows\CurrentVersion\Run" >> $FichierDémarrage
Get-ItemProperty "HKLM:\Software\Microsoft\Windows\CurrentVersion\Run" |Select-Object * -exclude PSPath,PSParentPath, PSChildName, PSProvider, PSDrive >> $FichierDémarrage
"HKLM:\Software\Microsoft\Windows\CurrentVersion\RunOnce" >> $FichierDémarrage
Get-ItemProperty "HKLM:\Software\Microsoft\Windows\CurrentVersion\RunOnce" |Select-Object * -exclude PSPath,PSParentPath, PSChildName, PSProvider, PSDrive >> $FichierDémarrage

Write-Host "Les résultats sont sauvegardés dans $FichierDémarrage" -ForegroundColor Green



Write-Host "================ Démarrage d'audit de configuration ================"
#Vérification de la politique des mots de passe
Write-Host "================ Audit des politiques des mots de passe ================"
#Vérification de renforcement de l'historique des mots de passe
$id = "PP1"
$statement = "(L1)Assurer que l'option 'Renforcer l'historique des mots de passe' est reglee sur '24 mot(s) de passe ou plus'"

$fileContent = Get-Content -Encoding UTF8 $fichier_secedit


$pattern1 = 'PasswordHistorySize\s*=\s*(\d+)'
$pattern2 = '(?<=PasswordHistorySize\s*:)\s*(\d+)'

foreach ($pattern in $pattern1, $pattern2) {
    $value = $fileContent | Select-String -pattern $pattern
     # Check for a match
    if ($value) {
      # Extract the captured value (first group)
      $realvalue = $value.Matches[0].Groups[1].Value
      $complianceStatus = if ($realvalue -ge 24) { "Conforme" } else { "Non-Conforme" }            
      $complianceData = New-Object PSObject -Property @{
        "ID" = $id
        "Status de conformité" = $complianceStatus
        "Point de contrôle" = $statement
       }
       $outputFile = "./Audit_config_" + "$OSName" + "_" + $Date + ".csv"
       $complianceData | Select-Object $columnOrder | Export-Csv -Path $outputFile -NoTypeInformation -Append -Encoding UTF8
       }
}

#Vérification de l'âge maximum du mot de passe
$id = "PP2"
$statement = "(L1)Assurer que L'âge maximum du mot de passe est fixé à 60 jours ou moins, mais pas à 0 :"

$pattern1 = 'MaximumPasswordAge\s*=\s*(\d+)'
$pattern2 = '(?<=MaximumPasswordAge\s*:)\s*(\d+)'

foreach ($pattern in $pattern1, $pattern2) {
    $value = $fileContent | Select-String -pattern $pattern |select-object -First 1
     # Check for a match
    if ($value) {
      # Extract the captured value (first group)
      $realvalue = $value.Matches[0].Groups[1].Value
      $complianceStatus = if ($realvalue -gt 0 -and $realvalue -le 60) { "Conforme" } else { "Non-Conforme" }            
      $complianceData = New-Object PSObject -Property @{
        "ID" = $id
        "Status de conformité" = $complianceStatus
        "Point de contrôle" = $statement
       }
       $outputFile = "./Audit_config_" + "$OSName" + "_" + $Date + ".csv"
       $complianceData | Select-Object $columnOrder | Export-Csv -Path $outputFile -NoTypeInformation -Append -Encoding UTF8
       }
}

#Vérification de l'age minimum de mots de passe
$id = "PP3"
$statement = "(L1)Assurer que l'âge minimum du mot de passe est fixé à 1 ou plusieurs jour(s) "

$pattern1 = 'MinimumPasswordAge\s*=\s*(\d+)'
$pattern2 = '(?<=MinimumPasswordAge\s*:)\s*(\d+)'

foreach ($pattern in $pattern1, $pattern2) {
    $value = $fileContent | Select-String -pattern $pattern
     # Check for a match
    if ($value) {
      # Extract the captured value (first group)
      $realvalue = $value.Matches[0].Groups[1].Value
      $complianceStatus = if ($realvalue -gt 1) { "Conforme" } else { "Non-Conforme" }            
      $complianceData = New-Object PSObject -Property @{
        "ID" = $id
        "Status de conformité" = $complianceStatus
        "Point de contrôle" = $statement
       }
       $outputFile = "./Audit_config_" + "$OSName" + "_" + $Date + ".csv"
       $complianceData | Select-Object $columnOrder | Export-Csv -Path $outputFile -NoTypeInformation -Append -Encoding UTF8
       }
}

#Vérification de la longueur minimale de mots de passe
$id = "PP4"
$statement = "(L1)Assurer que la longueur minimale du mot de passe est fixée à 14 caractères ou plus "

$pattern1 = 'MinimumPasswordLength\s*=\s*(\d+)'
$pattern2 = '(?<=MinimumPasswordLength\s*:)\s*(\d+)'

foreach ($pattern in $pattern1, $pattern2) {
    $value = $fileContent | Select-String -pattern $pattern
     # Check for a match
    if ($value) {
      # Extract the captured value (first group)
      $realvalue = $value.Matches[0].Groups[1].Value
      $complianceStatus = if ($realvalue -gt 14) { "Conforme" } else { "Non-Conforme" }            
      $complianceData = New-Object PSObject -Property @{
        "ID" = $id
        "Status de conformité" = $complianceStatus
        "Point de contrôle" = $statement
       }
       $outputFile = "./Audit_config_" + "$OSName" + "_" + $Date + ".csv"
       $complianceData | Select-Object $columnOrder | Export-Csv -Path $outputFile -NoTypeInformation -Append -Encoding UTF8
       }
}

#Vérification de la complexité de mots de passe
$id = "PP5"
$statement = "(L1)Assurer que l'option de la complexité est réglé sur activé"

$pattern1 = 'PasswordComplexity\s*=\s*(\d+)'
$pattern2 = '(?<=PasswordComplexity\s*:)\s*(\d+)'

foreach ($pattern in $pattern1, $pattern2) {
    $value = $fileContent | Select-String -pattern $pattern
     # Check for a match
    if ($value) {
      # Extract the captured value (first group)
      $realvalue = $value.Matches[0].Groups[1].Value
      $complianceStatus = if ($realvalue -eq 1) { "Conforme" } else { "Non-Conforme" }            
      $complianceData = New-Object PSObject -Property @{
        "ID" = $id
        "Status de conformité" = $complianceStatus
        "Point de contrôle" = $statement
       }
       $outputFile = "./Audit_config_" + "$OSName" + "_" + $Date + ".csv"
       $complianceData | Select-Object $columnOrder | Export-Csv -Path $outputFile -NoTypeInformation -Append -Encoding UTF8
       }
}

#Vérification de stockage des mots de passe :
$id = "PP6"
$statement = "(L1)Assurer que les mots de passe sont stockés à l'aide d'un chiffrement réversible"

$pattern1 = 'ClearTextPassword\s*=\s*(\d+)'
$pattern2 = '(?<=ClearTextPassword\s*:)\s*(\d+)'

foreach ($pattern in $pattern1, $pattern2) {
    $value = $fileContent | Select-String -pattern $pattern
     # Check for a match
    if ($value) {
      # Extract the captured value (first group)
      $realvalue = $value.Matches[0].Groups[1].Value
      $complianceStatus = if ($realvalue -eq 0) { "Conforme" } else { "Non-Conforme" }            
      $complianceData = New-Object PSObject -Property @{
        "ID" = $id
        "Status de conformité" = $complianceStatus
        "Point de contrôle" = $statement
       }
       $outputFile = "./Audit_config_" + "$OSName" + "_" + $Date + ".csv"
       $complianceData | Select-Object $columnOrder | Export-Csv -Path $outputFile -NoTypeInformation -Append -Encoding UTF8
       }
}


#Vérification de la politique de verrouillage des comptes 
Write-Host "================ Audit de la politique de verrouillage des comptes ================"

#Vérification de la durée de verrouillage des comptes
$id = "ALP1"
$statement = "(L1)Assurer que la durée de verrouillage du compte est réglée sur 15 minutes ou plus : "
$value = Get-Content $Fichiernetaccount |Select-String -pattern '(Durée du verrouillage)|(Lockout duration)'

$realvalue = $value -match '(?<=:)\s*(\d+)\s*$'

if ($realvalue) {
  # Extract the captured group (digits)
  $realvalue = [int]$matches[1]
  $complianceStatus = if ($realvalue -ge 15 ) { "Conforme" } else { "Non-Conforme" }
  $complianceData = New-Object PSObject -Property @{
        "ID" = $id
        "Status de conformité" = $complianceStatus
        "Point de contrôle" = $statement
       }
       $outputFile = "./Audit_config_" + "$OSName" + "_" + $Date + ".csv"
       $complianceData | Select-Object $columnOrder | Export-Csv -Path $outputFile -NoTypeInformation -Append -Encoding UTF8
       }


#Vérification de seuil de blocage du compte
$id = "ALP2" #needs more adjustments if the value is Never or jamais and not an integer
$statement = "(L1)Assurer que le seuil de verrouillage du compte est fixé à 10 tentatives de connexion non valides ou moins, mais pas à 0 ou jamais : "
$value = Get-Content $Fichiernetaccount |Select-String -pattern '(Seuil de verrouillage)|(Lockout threshold)'

$realvalue = $value -match '(?<=:)\s*(\d+)\s*$'

if ($realvalue) {
  # Extract the captured group (digits)
  $realvalue = [int]$matches[1]
  $complianceStatus = if ($realvalue -gt 0 -and $realvalue -le 5) { "Conforme" } else { "Non-Conforme" }
  $complianceData = New-Object PSObject -Property @{
        "ID" = $id
        "Status de conformité" = $complianceStatus
        "Point de contrôle" = $statement
       }
       $outputFile = "./Audit_config_" + "$OSName" + "_" + $Date + ".csv"
       $complianceData | Select-Object $columnOrder | Export-Csv -Path $outputFile -NoTypeInformation -Append -Encoding UTF8
       }


#Vérification de la réinitialisation du blocage de compte:
$id = "ALP3"
$statement ="(L1)Assurer que la réinitialisation du blocage de compte réglée sur 15 minutes ou plus"
$value = Get-Content $Fichiernetaccount |Select-String -pattern "(Fenêtre d'observation du verrouillage)|(Lockout observation window)"

$realvalue = $value -match '(?<=:)\s*(\d+)\s*$'

if ($realvalue) {
  # Extract the captured group (digits)
  $realvalue = [int]$matches[1]
  $complianceStatus = if ($realvalue -gt 15) { "Conforme" } else { "Non-Conforme" }
  $complianceData = New-Object PSObject -Property @{
        "ID" = $id
        "Status de conformité" = $complianceStatus
        "Point de contrôle" = $statement
       }
       $outputFile = "./Audit_config_" + "$OSName" + "_" + $Date + ".csv"
       $complianceData | Select-Object $columnOrder | Export-Csv -Path $outputFile -NoTypeInformation -Append -Encoding UTF8
       }



#Vérification de l'attribution des droits des utilisateurs 
Write-Host "================ Audit de l'attribution des droits des utilisateurs ================"


#Vérification d'accès à cette machine à partir du réseau
$id = "URA1"
$statement = "(L1) Assurer que l'accès à cet ordinateur à partir du réseau est uniquement pour Administrateurs, bureau à distance : "
$valueSID = Get-Content $fichier_secedit | Select-String "SeNetworkLogonRight"
$valueSID = $valueSID.Line
$users = Reverse-SID $valueSID

if ($users -eq $null -or $users -eq "") {
    $users = "Non-Configuré"
}

$complianceData = New-Object PSObject -Property @{
        "ID" = $id
        "Point de contrôle" = $statement
        "constat" = $users
       }
       $outputFile = "./Audit_Droits_utilisateurs.csv"
       $complianceData | Select-Object $columnOrder_constat | Export-Csv -Path $outputFile -NoTypeInformation -Append -Encoding UTF8


#Vérification d'autorisation de la connexion via RDP
$id = "URA2"
$statement = "(L1)Assurer que seulement les administrateurs et les utilisateurs du bureau à distance sont autorisés de se connecter via RDP :"
$valueSID = Get-Content $fichier_secedit |Select-String "SeRemoteInteractiveLogonRight"
$valueSID = $valueSID.line
$users = Reverse-SID $valueSID

$complianceData = New-Object PSObject -Property @{
        "ID" = $id
        "Point de contrôle" = $statement
        "constat" = $users
       }
       $outputFile = "./Audit_Droits_utilisateurs.csv"
       $complianceData | Select-Object $columnOrder_constat | Export-Csv -Path $outputFile -NoTypeInformation -Append -Encoding UTF8



#Vérification de privilège de sauvegarde
$id = "URA3"
$statement = "(L1)Assurer que 'privilège de sauvegarde' est défini sur 'Administrateurs': "
$valueSID = Get-Content $fichier_secedit |Select-String "SeBackupPrivilege"
$valueSID = $valueSID.line
$users = Reverse-SID $valueSID

if ($users -eq $null -or $users -eq "") {
    $users = "Non-Configuré"
}

$complianceData = New-Object PSObject -Property @{
        "ID" = $id
        "Point de contrôle" = $statement
        "constat" = $users
       }
       $outputFile = "./Audit_Droits_utilisateurs.csv"
       $complianceData | Select-Object $columnOrder_constat | Export-Csv -Path $outputFile -NoTypeInformation -Append -Encoding UTF8


#Vérification de la permission debug
$id = "URA4"
$statement = "(L1)Assurer que les programmes de débogage sont définis seulement pour les administrateurs "
$valueSID = Get-Content $fichier_secedit |Select-String "SeDebugPrivilege"
$valueSID = $valueSID.line
$users = Reverse-SID $valueSID

if ($users -eq $null -or $users -eq "") {
    $users = "Non-Configuré"
}

$complianceData = New-Object PSObject -Property @{
        "ID" = $id
        "Point de contrôle" = $statement
        "constat" = $users
       }
       $outputFile = "./Audit_Droits_utilisateurs.csv"
       $complianceData | Select-Object $columnOrder_constat | Export-Csv -Path $outputFile -NoTypeInformation -Append -Encoding UTF8

#Vérification de l'identité d'un client après l'authentification 
$id = "URA5"
$statement = "(L1)Assurer que l'usurpation d'identité d'un client lorsque l'authentification est définie sur administrateurs, service local, service réseau: "
$valueSID = Get-Content $fichier_secedit |Select-String "SeImpersonatePrivilege"
$valueSID = $valueSID.line
$users = Reverse-SID $valueSID

if ($users -eq $null -or $users -eq "") {
    $users = "Non-Configuré"
}

$complianceData = New-Object PSObject -Property @{
        "ID" = $id
        "Point de contrôle" = $statement
        "constat" = $users
       }
       $outputFile = "./Audit_Droits_utilisateurs.csv"
       $complianceData | Select-Object $columnOrder_constat | Export-Csv -Path $outputFile -NoTypeInformation -Append -Encoding UTF8


#vérification de la propriété des fichiers et autres objets
$id = "URA6"
$statement = "(L1)Assurer que la propriété des fichiers ou d'autres objets est réglée seulement sur 'Administrateurs': "
$valueSID = Get-Content $fichier_secedit |Select-String "SeTakeOwnershipPrivilege"
$valueSID = $valueSID.line
$users = Reverse-SID $valueSID

if ($users -eq $null -or $users -eq "") {
    $users = "Non-Configuré"
}

$complianceData = New-Object PSObject -Property @{
        "ID" = $id
        "Point de contrôle" = $statement
        "constat" = $users
       }
       $outputFile = "./Audit_Droits_utilisateurs.csv"
       $complianceData | Select-Object $columnOrder_constat | Export-Csv -Path $outputFile -NoTypeInformation -Append -Encoding UTF8


#vérification de l'arrêt de système
$id = "URA7"
$statement = "(L1)Assurer que l'option Arrêter le système est réglée seulement sur 'Administrateurs' et 'utilisateurs': "
$valueSID = Get-Content $fichier_secedit |Select-String "SeShutdownPrivilege"
$valueSID = $valueSID.line
$users = Reverse-SID $valueSID

if ($users -eq $null -or $users -eq "") {
    $users = "Non-Configuré"
}

$complianceData = New-Object PSObject -Property @{
        "ID" = $id
        "Point de contrôle" = $statement
        "constat" = $users
       }
       $outputFile = "./Audit_Droits_utilisateurs.csv"
       $complianceData | Select-Object $columnOrder_constat | Export-Csv -Path $outputFile -NoTypeInformation -Append -Encoding UTF8


#vérification de Modification d'heure du système
$id = "URA8"
$statement = "(L1)Assurer que l'option Modifier l'heure du système est réglée seulement sur 'Administrateurs' et 'service locale' et 'utilisateur': "
$valueSID = Get-Content $fichier_secedit |Select-String "SeSystemtimePrivilege"
$valueSID = $valueSID.line
$users = Reverse-SID $valueSID

if ($users -eq $null -or $users -eq "") {
    $users = "Non-Configuré"
}

$complianceData = New-Object PSObject -Property @{
        "ID" = $id
        "Point de contrôle" = $statement
        "constat" = $users
       }
       $outputFile = "./Audit_Droits_utilisateurs.csv"
       $complianceData | Select-Object $columnOrder_constat | Export-Csv -Path $outputFile -NoTypeInformation -Append -Encoding UTF8



#vérification de Création des liens symboliques
$id = "URA9"
$statement = "(L1)Assurer que l'option 'Créer des liens symboliques' est réglée seulement sur 'Administrateurs' : "
$valueSID = Get-Content $fichier_secedit |Select-String "SeCreateSymbolicLinkPrivilege"
$valueSID = $valueSID.line
$users = Reverse-SID $valueSID

if ($users -eq $null -or $users -eq "") {
    $users = "Non-Configuré"
}

$complianceData = New-Object PSObject -Property @{
        "ID" = $id
        "Point de contrôle" = $statement
        "constat" = $users
       }
       $outputFile = "./Audit_Droits_utilisateurs.csv"
       $complianceData | Select-Object $columnOrder_constat | Export-Csv -Path $outputFile -NoTypeInformation -Append -Encoding UTF8


#vérification de l'arrêt
$id = "URA10"
$statement = "(L1)Assurer que l'option 'forcer l'arrêt à partir d'un système distant' est réglée seulement sur 'Administrateurs' : "
$valueSID = Get-Content $fichier_secedit |Select-String "SeRemoteShutdownPrivilege"
$valueSID = $valueSID.line
$users = Reverse-SID $valueSID

if ($users -eq $null -or $users -eq "") {
    $users = "Non-Configuré"
}

$complianceData = New-Object PSObject -Property @{
        "ID" = $id
        "Point de contrôle" = $statement
        "constat" = $users
       }
       $outputFile = "./Audit_Droits_utilisateurs.csv"
       $complianceData | Select-Object $columnOrder_constat | Export-Csv -Path $outputFile -NoTypeInformation -Append -Encoding UTF8


#vérification de délégation
$id = "URA11"
$statement = "(L1)Assurer que l'option 'Autoriser les comptes d'ordinateur et d'utilisateur à être  pour la délégation' est réglée seulement sur 'personne' : "
$valueSID = Get-Content $fichier_secedit |Select-String "SeDelegateSessionUserImpersonatePrivilege"
$valueSID = $valueSID.line
$users = Reverse-SID $valueSID

if ($users -eq $null -or $users -eq "") {
    $users = "Non-Configuré"
}

$complianceData = New-Object PSObject -Property @{
        "ID" = $id
        "Point de contrôle" = $statement
        "constat" = $users
       }
       $outputFile = "./Audit_Droits_utilisateurs.csv"
       $complianceData | Select-Object $columnOrder_constat | Export-Csv -Path $outputFile -NoTypeInformation -Append -Encoding UTF8

Write-Host "Les résultats sont sauvegardés dans $outputFile" -ForegroundColor Green


#Vérification des comptes
Write-Host "================ Audit des comptes ================"



#Vérification de l'utilisation des mots de passe vierges
$id = "AA1"
$statement ="(L1)Assurer que l'utilisation de mots de passe vierges par les comptes locaux à la seule connexion à la console est défini sur Activé"
$exist = Test-Path HKLM:\SYSTEM\CurrentControlSet\Control\Lsa
if ( $exist -eq $true) {
  $value = Get-ItemProperty HKLM:\SYSTEM\CurrentControlSet\Control\Lsa |Select-Object LimitBlankPasswordUse
  $value = $value.LimitBlankPasswordUse
  $complianceStatus = if ($value -eq 1) { "Conforme" } else { "Non-Conforme" }
  $complianceData = New-Object PSObject -Property @{
        "ID" = $id
        "Point de contrôle" = $statement
        "Status de conformité" = $complianceStatus
       }
       $outputFile = "./Audit_config_" + "$OSName" + "_" + $Date + ".csv"
       $complianceData | Select-Object $columnOrder | Export-Csv -Path $outputFile -NoTypeInformation -Append -Encoding UTF8
       }
else {
  $complianceStatus="Non-Applicable"
  $complianceData = New-Object PSObject -Property @{
        "ID" = $id
        "Point de contrôle" = $statement
        "Status de conformité" = $complianceStatus
       }
       $outputFile = "./Audit_config_" + "$OSName" + "_" + $Date + ".csv"
       $complianceData | Select-Object $columnOrder | Export-Csv -Path $outputFile -NoTypeInformation -Append -Encoding UTF8
}


#vérification du compte invité
$id = "AA2"
$statement ="(L1)Assurer que le statut du compte invité est défini sur Désactivé"
$guestAccount = Get-LocalUser -Name "Guest", "Invité" -ErrorAction SilentlyContinue

$complianceStatus = if ($guestAccount.Enabled) { "Non-Conforme" } else { "Conforme" }
$complianceData = New-Object PSObject -Property @{
        "ID" = $id
        "Point de contrôle" = $statement
        "Status de conformité" = $complianceStatus
       }

$outputFile = "./Audit_config_" + "$OSName" + "_" + $Date + ".csv"
$complianceData | Select-Object $columnOrder | Export-Csv -Path $outputFile -NoTypeInformation -Append -Encoding UTF8


#Vérification d'accès au réseau
Write-Host "================ Audit d'accès au réseau ================"

#Vérification du translation SID/Name
$id = "NAA1"
$statement ="(L1)Assurer que l'option 'Autoriser la translation anonyme SID/Nom' est réglée sur 'Désactivé' "
$exist = Test-Path HKLM:\System\CurrentControlSet\Control\Lsa
if ( $exist -eq $true) {
  $value = Get-ItemProperty HKLM:\System\CurrentControlSet\Control\Lsa |Select-Object AnonymousNameLookup
  $value = $value.AnonymousNameLookup
  $complianceStatus = if ($value -eq 0) { "Conforme" } else { "Non-Conforme" }
  $complianceData = New-Object PSObject -Property @{
        "ID" = $id
        "Point de contrôle" = $statement
        "Status de conformité" = $complianceStatus
       }
       $outputFile = "./Audit_config_" + "$OSName" + "_" + $Date + ".csv"
       $complianceData | Select-Object $columnOrder | Export-Csv -Path $outputFile -NoTypeInformation -Append -Encoding UTF8
       }
else {
  $complianceStatus="Non-Applicable"
  $complianceData = New-Object PSObject -Property @{
        "ID" = $id
        "Point de contrôle" = $statement
        "Status de conformité" = $complianceStatus
       }
       $outputFile = "./Audit_config_" + "$OSName" + "_" + $Date + ".csv"
       $complianceData | Select-Object $columnOrder | Export-Csv -Path $outputFile -NoTypeInformation -Append -Encoding UTF8
}


#Vérification de l'énumeration anonyme des comptes SAM
$id = "NAA2"
$statement ="(L1)Assurer que l'option 'Ne pas autoriser l'énumération anonyme des comptes SAM' est réglée sur 'Activé' "
$exist = Test-Path HKLM:\SYSTEM\CurrentControlSet\Control\Lsa
if ( $exist -eq $true) {
  $value = Get-ItemProperty HKLM:\SYSTEM\CurrentControlSet\Control\Lsa |Select-Object RestrictAnonymousSAM
  $value = $value.RestrictAnonymousSAM
  $complianceStatus = if ($value -eq 1) { "Conforme" } else { "Non-Conforme" }
  $complianceData = New-Object PSObject -Property @{
        "ID" = $id
        "Point de contrôle" = $statement
        "Status de conformité" = $complianceStatus
       }
       $outputFile = "./Audit_config_" + "$OSName" + "_" + $Date + ".csv"
       $complianceData | Select-Object $columnOrder | Export-Csv -Path $outputFile -NoTypeInformation -Append -Encoding UTF8
       }
else {
  $complianceStatus="Non-Applicable"
  $complianceData = New-Object PSObject -Property @{
        "ID" = $id
        "Point de contrôle" = $statement
        "Status de conformité" = $complianceStatus
       }
       $outputFile = "./Audit_config_" + "$OSName" + "_" + $Date + ".csv"
       $complianceData | Select-Object $columnOrder | Export-Csv -Path $outputFile -NoTypeInformation -Append -Encoding UTF8
}

#Vérification d'accès anonyme aux Named Pipes
$id = "NAA3"
$statement ="(L1)Assurer que l'option 'Restreindre l'accès anonyme aux Named Pipes' est réglé sur Activé "
$exist = Test-Path HKLM:\SYSTEM\CurrentControlSet\Services\LanManServer\Parameters
if ( $exist -eq $true) {
  $value = Get-ItemProperty HKLM:\SYSTEM\CurrentControlSet\Services\LanManServer\Parameters |Select-Object NullSessionPipes
  $value = $value.NullSessionPipes
  $complianceStatus = if ($value -eq 1) { "Conforme" } else { "Non-Conforme" }
  $complianceData = New-Object PSObject -Property @{
        "ID" = $id
        "Point de contrôle" = $statement
        "Status de conformité" = $complianceStatus
       }
       $outputFile = "./Audit_config_" + "$OSName" + "_" + $Date + ".csv"
       $complianceData | Select-Object $columnOrder | Export-Csv -Path $outputFile -NoTypeInformation -Append -Encoding UTF8
       }
else {
  $complianceStatus="Non-Applicable"
  $complianceData = New-Object PSObject -Property @{
        "ID" = $id
        "Point de contrôle" = $statement
        "Status de conformité" = $complianceStatus
       }
       $outputFile = "./Audit_config_" + "$OSName" + "_" + $Date + ".csv"
       $complianceData | Select-Object $columnOrder | Export-Csv -Path $outputFile -NoTypeInformation -Append -Encoding UTF8
}

#Vérification de stockage des mots de passe pour l'authentification au réseau
$id = "NAA4"
$statement ="(L1)assurer que l'option 'Ne pas autoriser le stockage des mots de passe et des informations d'identification pour l'authentification réseau' est réglée sur Activé "
$exist = Test-Path HKLM:\System\CurrentControlSet\Control\Lsa
if ( $exist -eq $true) {
  $value = Get-ItemProperty HKLM:\System\CurrentControlSet\Control\Lsa |Select-Object DisableDomainCreds
  $value = $value.DisableDomainCreds
  $complianceStatus = if ($value -eq 1) { "Conforme" } else { "Non-Conforme" }
  $complianceData = New-Object PSObject -Property @{
        "ID" = $id
        "Point de contrôle" = $statement
        "Status de conformité" = $complianceStatus
       }
       $outputFile = "./Audit_config_" + "$OSName" + "_" + $Date + ".csv"
       $complianceData | Select-Object $columnOrder | Export-Csv -Path $outputFile -NoTypeInformation -Append -Encoding UTF8
       }
else {
  $complianceStatus="Non-Applicable"
  $complianceData = New-Object PSObject -Property @{
        "ID" = $id
        "Point de contrôle" = $statement
        "Status de conformité" = $complianceStatus
       }
       $outputFile = "./Audit_config_" + "$OSName" + "_" + $Date + ".csv"
       $complianceData | Select-Object $columnOrder | Export-Csv -Path $outputFile -NoTypeInformation -Append -Encoding UTF8
}

#Vérification d'autorisation d'un utilisateur anonyme
$id = "NAA5"
$statement ="(L1)Assurer que l'option 'Permettre à l'utilisateur anonyme de bénéficier des autorisations de tout le monde' est réglé sur Désactivé "
$exist = Test-Path HKLM:\System\CurrentControlSet\Control\Lsa
if ( $exist -eq $true) {
  $value = Get-ItemProperty HKLM:\System\CurrentControlSet\Control\Lsa |Select-Object EveryoneIncludesAnonymous
  $value = $value.EveryoneIncludesAnonymous
  $complianceStatus = if ($value -eq 0) { "Conforme" } else { "Non-Conforme" }
  $complianceData = New-Object PSObject -Property @{
        "ID" = $id
        "Point de contrôle" = $statement
        "Status de conformité" = $complianceStatus
       }
       $outputFile = "./Audit_config_" + "$OSName" + "_" + $Date + ".csv"
       $complianceData | Select-Object $columnOrder | Export-Csv -Path $outputFile -NoTypeInformation -Append -Encoding UTF8
       }
else {
  $complianceStatus="Non-Applicable"
  $complianceData = New-Object PSObject -Property @{
        "ID" = $id
        "Point de contrôle" = $statement
        "Status de conformité" = $complianceStatus
       }
       $outputFile = "./Audit_config_" + "$OSName" + "_" + $Date + ".csv"
       $complianceData | Select-Object $columnOrder | Export-Csv -Path $outputFile -NoTypeInformation -Append -Encoding UTF8
}

#Vérification d'accès anonyme aux partages
$id = "NAA6"
$statement ="(L1)Assurer que l'option 'Restreindre l'accès anonyme aux partages' est réglé sur Activé "
$exist = Test-Path HKLM:\SYSTEM\CurrentControlSet\Services\LanManServer\Parameters
if ( $exist -eq $true) {
  $value = Get-ItemProperty HKLM:\SYSTEM\CurrentControlSet\Services\LanManServer\Parameters |Select-Object NullSessionShares
  $value = $value.NullSessionShares
  $complianceStatus = if ($value -eq 1) { "Conforme" } else { "Non-Conforme" }
  $complianceData = New-Object PSObject -Property @{
        "ID" = $id
        "Point de contrôle" = $statement
        "Status de conformité" = $complianceStatus
       }
       $outputFile = "./Audit_config_" + "$OSName" + "_" + $Date + ".csv"
       $complianceData | Select-Object $columnOrder | Export-Csv -Path $outputFile -NoTypeInformation -Append -Encoding UTF8
       }
else {
  $complianceStatus="Non-Applicable"
  $complianceData = New-Object PSObject -Property @{
        "ID" = $id
        "Point de contrôle" = $statement
        "Status de conformité" = $complianceStatus
       }
       $outputFile = "./Audit_config_" + "$OSName" + "_" + $Date + ".csv"
       $complianceData | Select-Object $columnOrder | Export-Csv -Path $outputFile -NoTypeInformation -Append -Encoding UTF8
}


#Vérification de sécurité réseau
Write-Host "================ Audit de sécurité réseau ================"


# Vérification de l'identité de l'ordinateur pour NTLM
$id = "NSA1"
$statement ="(L1)Assurer que l'option 'Autoriser le système local à utiliser l'identité de l'ordinateur pour NTLM' est réglée sur 'Activée' "
$exist = Test-Path HKLM:\SYSTEM\CurrentControlSet\Control\Lsa
if ( $exist -eq $true) {
  $value = Get-ItemProperty HKLM:\SYSTEM\CurrentControlSet\Control\Lsa |Select-Object UseMachineId
  $value = $value.UseMachineId
  $complianceStatus = if ($value -ge 1) { "Conforme" } else { "Non-Conforme" }
  $complianceData = New-Object PSObject -Property @{
        "ID" = $id
        "Point de contrôle" = $statement
        "Status de conformité" = $complianceStatus
       }
       $outputFile = "./Audit_config_" + "$OSName" + "_" + $Date + ".csv"
       $complianceData | Select-Object $columnOrder | Export-Csv -Path $outputFile -NoTypeInformation -Append -Encoding UTF8
       }
else {
  $complianceStatus="Non-Applicable"
  $complianceData = New-Object PSObject -Property @{
        "ID" = $id
        "Point de contrôle" = $statement
        "Status de conformité" = $complianceStatus
       }
       $outputFile = "./Audit_config_" + "$OSName" + "_" + $Date + ".csv"
       $complianceData | Select-Object $columnOrder | Export-Csv -Path $outputFile -NoTypeInformation -Append -Encoding UTF8
}


#Vérification de stockage de Lan Manager hash
$id = "NSA2"
$statement ="(L1)Assurer que l'option 'Ne pas stocker la valeur de hachage du gestionnaire de réseau local lors du prochain changement de mot de passe' est activée "
$exist = Test-Path HKLM:\System\CurrentControlSet\Control\Lsa
if ( $exist -eq $true) {
  $value = Get-ItemProperty HKLM:\System\CurrentControlSet\Control\Lsa |Select-Object NoLMHash
  $value = $value.NoLMHash
  $complianceStatus = if ($value -eq 1) { "Conforme" } else { "Non-Conforme" }
  $complianceData = New-Object PSObject -Property @{
        "ID" = $id
        "Point de contrôle" = $statement
        "Status de conformité" = $complianceStatus
       }
       $outputFile = "./Audit_config_" + "$OSName" + "_" + $Date + ".csv"
       $complianceData | Select-Object $columnOrder | Export-Csv -Path $outputFile -NoTypeInformation -Append -Encoding UTF8
       }
else {
  $complianceStatus="Non-Applicable"
  $complianceData = New-Object PSObject -Property @{
        "ID" = $id
        "Point de contrôle" = $statement
        "Status de conformité" = $complianceStatus
       }
       $outputFile = "./Audit_config_" + "$OSName" + "_" + $Date + ".csv"
       $complianceData | Select-Object $columnOrder | Export-Csv -Path $outputFile -NoTypeInformation -Append -Encoding UTF8
}


# Vérification de l'utilisation de NTLMv2 à la place de LM et NTLM
$id = "NSA3"
$statement ="(L1)Assurer que l'option 'Le niveau d'authentification de Lan Manager' est réglée sur 'répondre seulement sur l'envoie des réponses NTLMv2' "
$exist = Test-Path HKLM:\System\CurrentControlSet\Control\Lsa
if ( $exist -eq $true) {
  $value = Get-ItemProperty HKLM:\System\CurrentControlSet\Control\Lsa |Select-Object LmCompatibilityLevel
  $value = $value.LmCompatibilityLevel
  $complianceStatus = if ($value -eq 5) { "Conforme" } else { "Non-Conforme" }
  $complianceData = New-Object PSObject -Property @{
        "ID" = $id
        "Point de contrôle" = $statement
        "Status de conformité" = $complianceStatus
       }
       $outputFile = "./Audit_config_" + "$OSName" + "_" + $Date + ".csv"
       $complianceData | Select-Object $columnOrder | Export-Csv -Path $outputFile -NoTypeInformation -Append -Encoding UTF8
       }
else {
  $complianceStatus="Non-Applicable"
  $complianceData = New-Object PSObject -Property @{
        "ID" = $id
        "Point de contrôle" = $statement
        "Status de conformité" = $complianceStatus
       }
       $outputFile = "./Audit_config_" + "$OSName" + "_" + $Date + ".csv"
       $complianceData | Select-Object $columnOrder | Export-Csv -Path $outputFile -NoTypeInformation -Append -Encoding UTF8
}


# Vérification de la négociation de signature du client LDAP
$id = "NSA4"
$statement ="(L1)Assurer que l'option 'Exigences de signature du client LDAP' est réglée sur 'Négocier la signature ou sur une valeur supérieure' "
$exist = Test-Path HKLM:\SYSTEM\CurrentControlSet\Services\LDAP
if ( $exist -eq $true) {
  $value = Get-ItemProperty "HKLM:\SYSTEM\CurrentControlSet\Services\LDAP"| Select-Object LDAPClientIntegrity
  $value = $value.LDAPClientIntegrity
  $complianceStatus = if ($value -ge 1) { "Conforme" } else { "Non-Conforme" }
  $complianceData = New-Object PSObject -Property @{
        "ID" = $id
        "Point de contrôle" = $statement
        "Status de conformité" = $complianceStatus
       }
       $outputFile = "./Audit_config_" + "$OSName" + "_" + $Date + ".csv"
       $complianceData | Select-Object $columnOrder | Export-Csv -Path $outputFile -NoTypeInformation -Append -Encoding UTF8
       }
else {
  $complianceStatus="Non-Applicable"
  $complianceData = New-Object PSObject -Property @{
        "ID" = $id
        "Point de contrôle" = $statement
        "Status de conformité" = $complianceStatus
       }
       $outputFile = "./Audit_config_" + "$OSName" + "_" + $Date + ".csv"
       $complianceData | Select-Object $columnOrder | Export-Csv -Path $outputFile -NoTypeInformation -Append -Encoding UTF8
}


#Vérification d'accès des utilisateurs
Write-Host "================ Audit d'accès des utilisateurs ================"

#Vérification de Mode d'approbation de l'administrateur pour le compte de l'administrateur intégré
$id = "UAC1"
$statement ="(L1)Assurer que le mode d'approbation de l'administrateur pour le compte de l'administrateur intégré est défini sur Activé. "
$exist = Test-Path HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\System
if ( $exist -eq $true) {
  $value = Get-ItemProperty HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\System | Select-Object FilterAdministratorToken
  $value = $value.FilterAdministratorToken
  $complianceStatus = if ($value -eq 1) { "Conforme" } else { "Non-Conforme" }
  $complianceData = New-Object PSObject -Property @{
        "ID" = $id
        "Point de contrôle" = $statement
        "Status de conformité" = $complianceStatus
       }
       $outputFile = "./Audit_config_" + "$OSName" + "_" + $Date + ".csv"
       $complianceData | Select-Object $columnOrder | Export-Csv -Path $outputFile -NoTypeInformation -Append -Encoding UTF8
       }
else {
  $complianceStatus="Non-Applicable"
  $complianceData = New-Object PSObject -Property @{
        "ID" = $id
        "Point de contrôle" = $statement
        "Status de conformité" = $complianceStatus
       }
       $outputFile = "./Audit_config_" + "$OSName" + "_" + $Date + ".csv"
       $complianceData | Select-Object $columnOrder | Export-Csv -Path $outputFile -NoTypeInformation -Append -Encoding UTF8
}

#Vérification de Comportement de l'invite d'élévation pour les utilisateurs standard
$id = "UAC2"
$statement ="(L1)assurer que le comportement de l'invite d'élévation pour les utilisateurs standard est défini sur Refuser automatiquement les demandes d'élévation "
$exist = Test-Path HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\System
if ( $exist -eq $true) {
  $value = Get-ItemProperty HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\System | Select-Object ConsentPromptBehaviorUser
  $value = $value.ConsentPromptBehaviorUser
  $complianceStatus = if ($value -eq 0) { "Conforme" } else { "Non-Conforme" }
  $complianceData = New-Object PSObject -Property @{
        "ID" = $id
        "Point de contrôle" = $statement
        "Status de conformité" = $complianceStatus
       }
       $outputFile = "./Audit_config_" + "$OSName" + "_" + $Date + ".csv"
       $complianceData | Select-Object $columnOrder | Export-Csv -Path $outputFile -NoTypeInformation -Append -Encoding UTF8
       }
else {
  $complianceStatus="Non-Applicable"
  $complianceData = New-Object PSObject -Property @{
        "ID" = $id
        "Point de contrôle" = $statement
        "Status de conformité" = $complianceStatus
       }
       $outputFile = "./Audit_config_" + "$OSName" + "_" + $Date + ".csv"
       $complianceData | Select-Object $columnOrder | Export-Csv -Path $outputFile -NoTypeInformation -Append -Encoding UTF8
}

#Vérification de détection d'installation des applications 
$id = "UAC3"
$statement ="(L1)assurer que l'option 'Détecter les installations d'applications et demander l'élévation' est activée "
$exist = Test-Path HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\System
if ( $exist -eq $true) {
  $value = Get-ItemProperty HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\System |Select-Object EnableInstallerDetection
  $value = $value.EnableInstallerDetection
  $complianceStatus = if ($value -eq 1) { "Conforme" } else { "Non-Conforme" }
  $complianceData = New-Object PSObject -Property @{
        "ID" = $id
        "Point de contrôle" = $statement
        "Status de conformité" = $complianceStatus
       }
       $outputFile = "./Audit_config_" + "$OSName" + "_" + $Date + ".csv"
       $complianceData | Select-Object $columnOrder | Export-Csv -Path $outputFile -NoTypeInformation -Append -Encoding UTF8
       }
else {
  $complianceStatus="Non-Applicable"
  $complianceData = New-Object PSObject -Property @{
        "ID" = $id
        "Point de contrôle" = $statement
        "Status de conformité" = $complianceStatus
       }
       $outputFile = "./Audit_config_" + "$OSName" + "_" + $Date + ".csv"
       $complianceData | Select-Object $columnOrder | Export-Csv -Path $outputFile -NoTypeInformation -Append -Encoding UTF8
}

#Vérification de pare-feu
Write-Host "================ Audit de pare-feu ================"

#Vérification de l'état de pare-feu
$id = "WDFA1"
$statement ="(L1)Assurer que l'option 'État du pare-feu' est défini sur Activé' "

$value = Get-NetFirewallProfile -Name "Domain" |Select-Object Enabled
$value = $value.Enabled
$complianceStatus = if ($value -eq "True" ) { "Conforme" } else { "Non-Conforme" }
$complianceData = New-Object PSObject -Property @{
      "ID" = $id
      "Point de contrôle" = $statement
      "Status de conformité" = $complianceStatus
      }
$outputFile = "./Audit_config_" + "$OSName" + "_" + $Date + ".csv"
$complianceData | Select-Object $columnOrder | Export-Csv -Path $outputFile -NoTypeInformation -Append -Encoding UTF8


#Vérification de connexions entrantes
$id = "WDFA2"
$statement ="(L1)Assurer que l'option 'Connexions entrantes' est défini sur 'bloquer' "

$value = Get-NetFirewallProfile -Name "Domain" |Select-Object DefaultInboundAction
$value = $value.DefaultInboundAction
$complianceStatus = if ($value -eq "Block" ) { "Conforme" } else { "Non-Conforme" }
$complianceData = New-Object PSObject -Property @{
      "ID" = $id
      "Point de contrôle" = $statement
      "Status de conformité" = $complianceStatus
      }
$outputFile = "./Audit_config_" + "$OSName" + "_" + $Date + ".csv"
$complianceData | Select-Object $columnOrder | Export-Csv -Path $outputFile -NoTypeInformation -Append -Encoding UTF8



#Vérification Sécurité MS
Write-Host "================ Audit de MS Sécurité ================"


#Vérification de l'authentification WDigest 
$id = "MSSGA1"
$statement ="(L1)Assurer que l'option 'Authentification WDigest' est réglée sur Désactiver "
$exist = Test-Path HKLM:\SYSTEM\CurrentControlSet\Control\SecurityProviders\WDigest
if ( $exist -eq $true) {
  $value = Get-ItemProperty HKLM:\SYSTEM\CurrentControlSet\Control\SecurityProviders\WDigest |Select-Object UseLogonCredential
  $value = $value.UseLogonCredential
  $complianceStatus = if ($value -eq 0) { "Conforme" } else { "Non-Conforme" }
  $complianceData = New-Object PSObject -Property @{
        "ID" = $id
        "Point de contrôle" = $statement
        "Status de conformité" = $complianceStatus
       }
       $outputFile = "./Audit_config_" + "$OSName" + "_" + $Date + ".csv"
       $complianceData | Select-Object $columnOrder | Export-Csv -Path $outputFile -NoTypeInformation -Append -Encoding UTF8
       }
else {
  $complianceStatus="Non-Applicable"
  $complianceData = New-Object PSObject -Property @{
        "ID" = $id
        "Point de contrôle" = $statement
        "Status de conformité" = $complianceStatus
       }
       $outputFile = "./Audit_config_" + "$OSName" + "_" + $Date + ".csv"
       $complianceData | Select-Object $columnOrder | Export-Csv -Path $outputFile -NoTypeInformation -Append -Encoding UTF8
}


#Vérification de protection du routage de la source IP 
$id = "MSSGA2"
$statement ="(L1)Assurer que l'option 'Protection du routage de la source IP' est réglée sur Activer "
$exist = Test-Path HKLM:\SYSTEM\CurrentControlSet\Services\Tcpip\Parameters
if ( $exist -eq $true) {
  $value = Get-ItemProperty HKLM:\SYSTEM\CurrentControlSet\Services\Tcpip\Parameters |Select-Object disableIPSourceRouting
  $value = $value.disableIPSourceRouting
  $complianceStatus = if ($value -eq 2) { "Conforme" } else { "Non-Conforme" }
  $complianceData = New-Object PSObject -Property @{
        "ID" = $id
        "Point de contrôle" = $statement
        "Status de conformité" = $complianceStatus
       }
       $outputFile = "./Audit_config_" + "$OSName" + "_" + $Date + ".csv"
       $complianceData | Select-Object $columnOrder | Export-Csv -Path $outputFile -NoTypeInformation -Append -Encoding UTF8
       }
else {
  $complianceStatus="Non-Applicable"
  $complianceData = New-Object PSObject -Property @{
        "ID" = $id
        "Point de contrôle" = $statement
        "Status de conformité" = $complianceStatus
       }
       $outputFile = "./Audit_config_" + "$OSName" + "_" + $Date + ".csv"
       $complianceData | Select-Object $columnOrder | Export-Csv -Path $outputFile -NoTypeInformation -Append -Encoding UTF8
}


#Vérification de connexion automatique de l'administrateur
$id = "MSSGA3"
$statement ="(L1)Assurer que l'option 'Autoriser la connexion automatique' est réglée sur Désactiver "
$exist = Test-Path "HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Winlogon"
if ( $exist -eq $true) {
  $value = Get-ItemProperty "HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Winlogon"|Select-Object AutoAdminLogon
  $value = $value.AutoAdminLogon
  $complianceStatus = if ($value -eq 0) { "Conforme" } else { "Non-Conforme" }
  $complianceData = New-Object PSObject -Property @{
        "ID" = $id
        "Point de contrôle" = $statement
        "Status de conformité" = $complianceStatus
       }
       $outputFile = "./Audit_config_" + "$OSName" + "_" + $Date + ".csv"
       $complianceData | Select-Object $columnOrder | Export-Csv -Path $outputFile -NoTypeInformation -Append -Encoding UTF8
       }
else {
  $complianceStatus="Non-Applicable"
  $complianceData = New-Object PSObject -Property @{
        "ID" = $id
        "Point de contrôle" = $statement
        "Status de conformité" = $complianceStatus
       }
       $outputFile = "./Audit_config_" + "$OSName" + "_" + $Date + ".csv"
       $complianceData | Select-Object $columnOrder | Export-Csv -Path $outputFile -NoTypeInformation -Append -Encoding UTF8
}

#Vérification de réseau
Write-Host "================ Audit de réseau ================"

#Vérification des connexions d'invités non sécurisées
$id = "NA1"
$statement ="(L1)Assurer que l'option 'Activer les connexions d'invités non sécurisées' est réglée sur désactivé "
$exist = Test-Path HKLM:\SOFTWARE\Policies\Microsoft\Windows\LanmanWorkstation
if ( $exist -eq $true) {
  $value = Get-ItemProperty HKLM:\SOFTWARE\Policies\Microsoft\Windows\LanmanWorkstation |Select-Object AllowInsecureGuestAuth
  $value = $value.AllowInsecureGuestAuth
  $complianceStatus = if ($value -eq 0) { "Conforme" } else { "Non-Conforme" }
  $complianceData = New-Object PSObject -Property @{
        "ID" = $id
        "Point de contrôle" = $statement
        "Status de conformité" = $complianceStatus
       }
       $outputFile = "./Audit_config_" + "$OSName" + "_" + $Date + ".csv"
       $complianceData | Select-Object $columnOrder | Export-Csv -Path $outputFile -NoTypeInformation -Append -Encoding UTF8
       }
else {
  $complianceStatus="Non-Applicable"
  $complianceData = New-Object PSObject -Property @{
        "ID" = $id
        "Point de contrôle" = $statement
        "Status de conformité" = $complianceStatus
       }
       $outputFile = "./Audit_config_" + "$OSName" + "_" + $Date + ".csv"
       $complianceData | Select-Object $columnOrder | Export-Csv -Path $outputFile -NoTypeInformation -Append -Encoding UTF8
}


#Vérification de Kerberos
Write-Host "================ Audit de kerberos ================"

#Vérification d'authentification en utilisant les certificats
$id = "KA1"
$statement ="(L2)Assurer que l'option 'Prise en charge de l'authentification de l'appareil à l'aide d'un certificat' est réglée sur Activé "
$exist = Test-Path HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\System\kerberos\parameters
if ( $exist -eq $true) {
  $value1 = Get-ItemProperty HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\System\kerberos\parameters |Select-Object DevicePKInitBehavior
  $value1 = $value1.DevicePKInitBehavior
  $value2 = Get-ItemProperty HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\System\kerberos\parameters |Select-Object DevicePKInitEnabled
  $value2 = $value2.DevicePKInitEnabled
 
  $complianceStatus = if ($value1 -eq 1 -and $value2 -eq 1) { "Conforme" } else { "Non-Conforme" }
  $complianceData = New-Object PSObject -Property @{
        "ID" = $id
        "Point de contrôle" = $statement
        "Status de conformité" = $complianceStatus
       }
       $outputFile = "./Audit_config_" + "$OSName" + "_" + $Date + ".csv"
       $complianceData | Select-Object $columnOrder | Export-Csv -Path $outputFile -NoTypeInformation -Append -Encoding UTF8
       }
else {
  $complianceStatus="Non-Applicable"
  $complianceData = New-Object PSObject -Property @{
        "ID" = $id
        "Point de contrôle" = $statement
        "Status de conformité" = $complianceStatus
       }
       $outputFile = "./Audit_config_" + "$OSName" + "_" + $Date + ".csv"
       $complianceData | Select-Object $columnOrder | Export-Csv -Path $outputFile -NoTypeInformation -Append -Encoding UTF8
}



#Vérification de la politique d'autoplay
Write-Host "================ Audit de la politique d'autoplay ================"

#Vérification de la politique d'autoplay pour les appareils sans volume
$id = "AP1"
$statement ="(L1)Assurer que l'option 'Désactiver l'autoplay pour les appareils sans volume' est réglée sur Activé "
$exist = Test-Path HKLM:\SOFTWARE\Policies\Microsoft\Windows\Explorer
if ( $exist -eq $true) {
  $value = Get-ItemProperty HKLM:\SOFTWARE\Policies\Microsoft\Windows\Explorer |Select-Object NoAutoplayfornonVolume
  $value = $value.NoAutoplayfornonVolume
  $complianceStatus = if ($value -eq 1) { "Conforme" } else { "Non-Conforme" }
  $complianceData = New-Object PSObject -Property @{
        "ID" = $id
        "Point de contrôle" = $statement
        "Status de conformité" = $complianceStatus
       }
       $outputFile = "./Audit_config_" + "$OSName" + "_" + $Date + ".csv"
       $complianceData | Select-Object $columnOrder | Export-Csv -Path $outputFile -NoTypeInformation -Append -Encoding UTF8
       }
else {
  $complianceStatus="Non-Applicable"
  $complianceData = New-Object PSObject -Property @{
        "ID" = $id
        "Point de contrôle" = $statement
        "Status de conformité" = $complianceStatus
       }
       $outputFile = "./Audit_config_" + "$OSName" + "_" + $Date + ".csv"
       $complianceData | Select-Object $columnOrder | Export-Csv -Path $outputFile -NoTypeInformation -Append -Encoding UTF8
}

#Vérification de comportement d'autoplay par défaut
$id = "AP2"
$statement ="(L1)Assurer que l'option 'Le comportement par défaut de l'AutoRun' est réglée sur 'Activé : Ne pas executer les commandes de l'Autorun' "
$exist = Test-Path HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\Explorer
if ( $exist -eq $true) {
  $value = Get-ItemProperty HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\Explorer |Select-Object NoAutorun
  $value = $value.NoAutorun
  $complianceStatus = if ($value -eq 1) { "Conforme" } else { "Non-Conforme" }
  $complianceData = New-Object PSObject -Property @{
        "ID" = $id
        "Point de contrôle" = $statement
        "Status de conformité" = $complianceStatus
       }
       $outputFile = "./Audit_config_" + "$OSName" + "_" + $Date + ".csv"
       $complianceData | Select-Object $columnOrder | Export-Csv -Path $outputFile -NoTypeInformation -Append -Encoding UTF8
       }
else {
  $complianceStatus="Non-Applicable"
  $complianceData = New-Object PSObject -Property @{
        "ID" = $id
        "Point de contrôle" = $statement
        "Status de conformité" = $complianceStatus
       }
       $outputFile = "./Audit_config_" + "$OSName" + "_" + $Date + ".csv"
       $complianceData | Select-Object $columnOrder | Export-Csv -Path $outputFile -NoTypeInformation -Append -Encoding UTF8
}

#Vérification de la politique d'autoplay pour tous les volumes
$id = "AP3"
$statement = "(L1)Assurer que l'option 'Désactiver la lecture automatique ' est réglée sur Activé "
$exist = Test-Path "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\Explorer"
if ( $exist -eq $true) {
  $value = Get-ItemProperty "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\Explorer" |Select-Object NoDriveTypeAutoRun
  $value = $value.NoDriveTypeAutoRun
  $complianceStatus = if ($value -eq 255) { "Conforme" } else { "Non-Conforme" }
  $complianceData = New-Object PSObject -Property @{
        "ID" = $id
        "Point de contrôle" = $statement
        "Status de conformité" = $complianceStatus
       }
       $outputFile = "./Audit_config_" + "$OSName" + "_" + $Date + ".csv"
       $complianceData | Select-Object $columnOrder | Export-Csv -Path $outputFile -NoTypeInformation -Append -Encoding UTF8
       }
else {
  $complianceStatus="Non-Applicable"
  $complianceData = New-Object PSObject -Property @{
        "ID" = $id
        "Point de contrôle" = $statement
        "Status de conformité" = $complianceStatus
       }
       $outputFile = "./Audit_config_" + "$OSName" + "_" + $Date + ".csv"
       $complianceData | Select-Object $columnOrder | Export-Csv -Path $outputFile -NoTypeInformation -Append -Encoding UTF8
}


#Vérification client RDP
Write-Host "================ Audit de client RDP ================"


#Vérification de la redirection WebAuthn
$id = "RCA1"
$statement ="(L1)Assurer que l'option 'Ne pas autoriser la redirection WebAuthn' est réglée sur Activé "
$exist = Test-Path "HKLM:\SOFTWARE\Policies\Microsoft\Windows NT\Terminal Services"
if ( $exist -eq $true) {
  $value = Get-ItemProperty "HKLM:\SOFTWARE\Policies\Microsoft\Windows NT\Terminal Services" |Select-Object fDisableWebAuthn
  $value = $value.fDisableWebAuthn
  $complianceStatus = if ($value -eq 1) { "Conforme" } else { "Non-Conforme" }
  $complianceData = New-Object PSObject -Property @{
        "ID" = $id
        "Point de contrôle" = $statement
        "Status de conformité" = $complianceStatus
       }
       $outputFile = "./Audit_config_" + "$OSName" + "_" + $Date + ".csv"
       $complianceData | Select-Object $columnOrder | Export-Csv -Path $outputFile -NoTypeInformation -Append -Encoding UTF8
       }
else {
  $complianceStatus="Non-Applicable"
  $complianceData = New-Object PSObject -Property @{
        "ID" = $id
        "Point de contrôle" = $statement
        "Status de conformité" = $complianceStatus
       }
       $outputFile = "./Audit_config_" + "$OSName" + "_" + $Date + ".csv"
       $complianceData | Select-Object $columnOrder | Export-Csv -Path $outputFile -NoTypeInformation -Append -Encoding UTF8
}

#Vérification de permission de se connecter à distance 
$id = "RCA2"
$statement ="(L1)Assurer que l'option 'Permettre aux utilisateurs de se connecter à distance en utilisant les services de bureau à distance' est réglée sur Désactivé "
$exist = Test-Path "HKLM:\SOFTWARE\Policies\Microsoft\Windows NT\Terminal Services"
if ( $exist -eq $true) {
  $value = Get-ItemProperty "HKLM:\SOFTWARE\Policies\Microsoft\Windows NT\Terminal Services" |Select-Object fDenyTSConnections
  $value = $value.fDenyTSConnections
  $complianceStatus = if ($value -eq 0) { "Conforme" } else { "Non-Conforme" }
  $complianceData = New-Object PSObject -Property @{
        "ID" = $id
        "Point de contrôle" = $statement
        "Status de conformité" = $complianceStatus
       }
       $outputFile = "./Audit_config_" + "$OSName" + "_" + $Date + ".csv"
       $complianceData | Select-Object $columnOrder | Export-Csv -Path $outputFile -NoTypeInformation -Append -Encoding UTF8
       }
else {
  $complianceStatus="Non-Applicable"
  $complianceData = New-Object PSObject -Property @{
        "ID" = $id
        "Point de contrôle" = $statement
        "Status de conformité" = $complianceStatus
       }
       $outputFile = "./Audit_config_" + "$OSName" + "_" + $Date + ".csv"
       $complianceData | Select-Object $columnOrder | Export-Csv -Path $outputFile -NoTypeInformation -Append -Encoding UTF8
}

#Vérification de la sauvegarde des mots de passe
$id = "RCA3"
$statement ="(L1)Assurer que l'option 'Ne pas autoriser l'enregistrement des mots de passe' est réglée sur Activé "
$exist = Test-Path "HKLM:\SOFTWARE\Policies\Microsoft\Windows NT\Terminal Services"
if ( $exist -eq $true) {
  $value = Get-ItemProperty "HKLM:\SOFTWARE\Policies\Microsoft\Windows NT\Terminal Services" |Select-Object DisablePasswordSaving
  $value = $value.DisablePasswordSaving
  $complianceStatus = if ($value -eq 1) { "Conforme" } else { "Non-Conforme" }
  $complianceData = New-Object PSObject -Property @{
        "ID" = $id
        "Point de contrôle" = $statement
        "Status de conformité" = $complianceStatus
       }
       $outputFile = "./Audit_config_" + "$OSName" + "_" + $Date + ".csv"
       $complianceData | Select-Object $columnOrder | Export-Csv -Path $outputFile -NoTypeInformation -Append -Encoding UTF8
       }
else {
  $complianceStatus="Non-Applicable"
  $complianceData = New-Object PSObject -Property @{
        "ID" = $id
        "Point de contrôle" = $statement
        "Status de conformité" = $complianceStatus
       }
       $outputFile = "./Audit_config_" + "$OSName" + "_" + $Date + ".csv"
       $complianceData | Select-Object $columnOrder | Export-Csv -Path $outputFile -NoTypeInformation -Append -Encoding UTF8
}


#Vérification de la redirection de l'automatisation de l'interface utilisateur
$id = "RCA4"
$statement ="(L1)Assurer que l'option 'Autoriser la redirection de l'automatisation de l'interface utilisateur' est réglée sur Désactivé "
$exist = Test-Path "HKLM:\SOFTWARE\Policies\Microsoft\Windows NT\Terminal Services"
if ( $exist -eq $true) {
  $value = Get-ItemProperty "HKLM:\SOFTWARE\Policies\Microsoft\Windows NT\Terminal Services" |Select-Object EnableUiaRedirection
  $value = $value.EnableUiaRedirection
  $complianceStatus = if ($value -eq 0) { "Conforme" } else { "Non-Conforme" }
  $complianceData = New-Object PSObject -Property @{
        "ID" = $id
        "Point de contrôle" = $statement
        "Status de conformité" = $complianceStatus
       }
       $outputFile = "./Audit_config_" + "$OSName" + "_" + $Date + ".csv"
       $complianceData | Select-Object $columnOrder | Export-Csv -Path $outputFile -NoTypeInformation -Append -Encoding UTF8
       }
else {
  $complianceStatus="Non-Applicable"
  $complianceData = New-Object PSObject -Property @{
        "ID" = $id
        "Point de contrôle" = $statement
        "Status de conformité" = $complianceStatus
       }
       $outputFile = "./Audit_config_" + "$OSName" + "_" + $Date + ".csv"
       $complianceData | Select-Object $columnOrder | Export-Csv -Path $outputFile -NoTypeInformation -Append -Encoding UTF8
}

#Vérification d'authentification via Network Level Authentication 
$id = "RCA5"
$statement ="(L1)Assurer que l'option 'Exiger l'authentification de l'utilisateur pour les connexions à distance en utilisant l'authentification au niveau du réseau' est réglée sur Activé "
$exist = Test-Path "HKLM:\SOFTWARE\Policies\Microsoft\Windows NT\Terminal Services"
if ( $exist -eq $true) {
  $value = Get-ItemProperty "HKLM:\SOFTWARE\Policies\Microsoft\Windows NT\Terminal Services" |Select-Object UserAuthentication
  $value = $value.UserAuthentication
  $complianceStatus = if ($value -eq 1) { "Conforme" } else { "Non-Conforme" }
  $complianceData = New-Object PSObject -Property @{
        "ID" = $id
        "Point de contrôle" = $statement
        "Status de conformité" = $complianceStatus
       }
       $outputFile = "./Audit_config_" + "$OSName" + "_" + $Date + ".csv"
       $complianceData | Select-Object $columnOrder | Export-Csv -Path $outputFile -NoTypeInformation -Append -Encoding UTF8
       }
else {
  $complianceStatus="Non-Applicable"
  $complianceData = New-Object PSObject -Property @{
        "ID" = $id
        "Point de contrôle" = $statement
        "Status de conformité" = $complianceStatus
       }
       $outputFile = "./Audit_config_" + "$OSName" + "_" + $Date + ".csv"
       $complianceData | Select-Object $columnOrder | Export-Csv -Path $outputFile -NoTypeInformation -Append -Encoding UTF8
}

#Vérification de connexion
$id = "RCA6"
$statement ="(L1)Assurer que l'option 'Toujours demander le mot de passe lors de la connexion' est réglée sur Activé "
$exist = Test-Path "HKLM:\SOFTWARE\Policies\Microsoft\Windows NT\Terminal Services"
if ( $exist -eq $true) {
  $value = Get-ItemProperty "HKLM:\SOFTWARE\Policies\Microsoft\Windows NT\Terminal Services" |Select-Object fPromptForPassword
  $value = $value.fPromptForPassword
  $complianceStatus = if ($value -eq 1) { "Conforme" } else { "Non-Conforme" }
  $complianceData = New-Object PSObject -Property @{
        "ID" = $id
        "Point de contrôle" = $statement
        "Status de conformité" = $complianceStatus
       }
       $outputFile = "./Audit_config_" + "$OSName" + "_" + $Date + ".csv"
       $complianceData | Select-Object $columnOrder | Export-Csv -Path $outputFile -NoTypeInformation -Append -Encoding UTF8
       }
else {
  $complianceStatus="Non-Applicable"
  $complianceData = New-Object PSObject -Property @{
        "ID" = $id
        "Point de contrôle" = $statement
        "Status de conformité" = $complianceStatus
       }
       $outputFile = "./Audit_config_" + "$OSName" + "_" + $Date + ".csv"
       $complianceData | Select-Object $columnOrder | Export-Csv -Path $outputFile -NoTypeInformation -Append -Encoding UTF8
}

#Vérification de niveau de chiffrement 
$id = "RCA7"
$statement ="(L1)Assurer que l'option 'Définir le niveau de cryptage de la connexion client' est réglée sur haut niveau "
$exist = Test-Path "HKLM:\SOFTWARE\Policies\Microsoft\Windows NT\Terminal Services"
if ( $exist -eq $true) {
  $value = Get-ItemProperty "HKLM:\SOFTWARE\Policies\Microsoft\Windows NT\Terminal Services" |Select-Object MinEncryptionLevel
  $value = $value.MinEncryptionLevel
  $complianceStatus = if ($value -eq 3) { "Conforme" } else { "Non-Conforme" }
  $complianceData = New-Object PSObject -Property @{
        "ID" = $id
        "Point de contrôle" = $statement
        "Status de conformité" = $complianceStatus
       }
       $outputFile = "./Audit_config_" + "$OSName" + "_" + $Date + ".csv"
       $complianceData | Select-Object $columnOrder | Export-Csv -Path $outputFile -NoTypeInformation -Append -Encoding UTF8
       }
else {
  $complianceStatus="Non-Applicable"
  $complianceData = New-Object PSObject -Property @{
        "ID" = $id
        "Point de contrôle" = $statement
        "Status de conformité" = $complianceStatus
       }
       $outputFile = "./Audit_config_" + "$OSName" + "_" + $Date + ".csv"
       $complianceData | Select-Object $columnOrder | Export-Csv -Path $outputFile -NoTypeInformation -Append -Encoding UTF8
}

#Vérification Windows Defender 
Write-Host "================ Audit de Windows defender ================"


#Vérification de la détection des applications potentiellement indésirables
$id = "WDA1"
$statement ="(L1)Assurer que l'option 'Configurer la détection des applications potentiellement indésirables' est réglée sur Activé "
$exist = Test-Path "HKLM:\SOFTWARE\Policies\Microsoft\Windows Defender"
if ( $exist -eq $true) {
  $value = Get-ItemProperty "HKLM:\SOFTWARE\Policies\Microsoft\Windows Defender" |Select-Object PUAProtection
  $value = $value.PUAProtection
  $complianceStatus = if ($value -eq 1) { "Conforme" } else { "Non-Conforme" }
  $complianceData = New-Object PSObject -Property @{
        "ID" = $id
        "Point de contrôle" = $statement
        "Status de conformité" = $complianceStatus
       }
       $outputFile = "./Audit_config_" + "$OSName" + "_" + $Date + ".csv"
       $complianceData | Select-Object $columnOrder | Export-Csv -Path $outputFile -NoTypeInformation -Append -Encoding UTF8
       }
else {
  $complianceStatus="Non-Applicable"
  $complianceData = New-Object PSObject -Property @{
        "ID" = $id
        "Point de contrôle" = $statement
        "Status de conformité" = $complianceStatus
       }
       $outputFile = "./Audit_config_" + "$OSName" + "_" + $Date + ".csv"
       $complianceData | Select-Object $columnOrder | Export-Csv -Path $outputFile -NoTypeInformation -Append -Encoding UTF8
}

#Vérification de l'activation de la surveillance en temps réel
$id = "WDA2"
$statement ="(L1)Assurer que l'option 'Désactiver la surveillance des comportements' est réglée sur Désactivé "
$exist = Test-Path "HKLM:\SOFTWARE\Policies\Microsoft\Windows Defender\Real-Time Protection"
if ( $exist -eq $true) {
  $value = Get-ItemProperty "HKLM:\SOFTWARE\Policies\Microsoft\Windows Defender\Real-Time Protection" |Select-Object DisableRealtimeMonitoring
  $value = $value.DisableRealtimeMonitoring
  $complianceStatus = if ($value -eq 0) { "Conforme" } else { "Non-Conforme" }
  $complianceData = New-Object PSObject -Property @{
        "ID" = $id
        "Point de contrôle" = $statement
        "Status de conformité" = $complianceStatus
       }
       $outputFile = "./Audit_config_" + "$OSName" + "_" + $Date + ".csv"
       $complianceData | Select-Object $columnOrder | Export-Csv -Path $outputFile -NoTypeInformation -Append -Encoding UTF8
       }
else {
  $complianceStatus="Non-Applicable"
  $complianceData = New-Object PSObject -Property @{
        "ID" = $id
        "Point de contrôle" = $statement
        "Status de conformité" = $complianceStatus
       }
       $outputFile = "./Audit_config_" + "$OSName" + "_" + $Date + ".csv"
       $complianceData | Select-Object $columnOrder | Export-Csv -Path $outputFile -NoTypeInformation -Append -Encoding UTF8
}

#Vérification de l'activation de la surveillance des comportements
$id = "WDA3"
$statement ="(L1)Assurer que l'option 'Activer la surveillance des comportements' est réglée sur Activé "
$exist = Test-Path "HKLM:\SOFTWARE\Policies\Microsoft\Windows Defender\Real-Time Protection"
if ( $exist -eq $true) {
  $value = Get-ItemProperty "HKLM:\SOFTWARE\Policies\Microsoft\Windows Defender\Real-Time Protection" |Select-Object DisableBehaviorMonitoring
  $value = $value.DisableBehaviorMonitoring
  $complianceStatus = if ($value -eq 0) { "Conforme" } else { "Non-Conforme" }
  $complianceData = New-Object PSObject -Property @{
        "ID" = $id
        "Point de contrôle" = $statement
        "Status de conformité" = $complianceStatus
       }
       $outputFile = "./Audit_config_" + "$OSName" + "_" + $Date + ".csv"
       $complianceData | Select-Object $columnOrder | Export-Csv -Path $outputFile -NoTypeInformation -Append -Encoding UTF8
       }
else {
  $complianceStatus="Non-Applicable"
  $complianceData = New-Object PSObject -Property @{
        "ID" = $id
        "Point de contrôle" = $statement
        "Status de conformité" = $complianceStatus
       }
       $outputFile = "./Audit_config_" + "$OSName" + "_" + $Date + ".csv"
       $complianceData | Select-Object $columnOrder | Export-Csv -Path $outputFile -NoTypeInformation -Append -Encoding UTF8
}

#Vérification de l'activation de l'antivirus
$id = "WDA4"
$statement ="(L1)Assurer que l'option 'Désactiver l'antivirus Windows Defender' est réglée sur Désactivé "
$exist = Test-Path "HKLM:\SOFTWARE\Policies\Microsoft\Windows Defender"
if ( $exist -eq $true) {
  $value = Get-ItemProperty "HKLM:\SOFTWARE\Policies\Microsoft\Windows Defender" |Select-Object DisableAntiSpyware
  $value = $value.DisableAntiSpyware
  $complianceStatus = if ($value -eq 0) { "Conforme" } else { "Non-Conforme" }
  $complianceData = New-Object PSObject -Property @{
        "ID" = $id
        "Point de contrôle" = $statement
        "Status de conformité" = $complianceStatus
       }
       $outputFile = "./Audit_config_" + "$OSName" + "_" + $Date + ".csv"
       $complianceData | Select-Object $columnOrder | Export-Csv -Path $outputFile -NoTypeInformation -Append -Encoding UTF8
       }
else {
  $complianceStatus="Non-Applicable"
  $complianceData = New-Object PSObject -Property @{
        "ID" = $id
        "Point de contrôle" = $statement
        "Status de conformité" = $complianceStatus
       }
       $outputFile = "./Audit_config_" + "$OSName" + "_" + $Date + ".csv"
       $complianceData | Select-Object $columnOrder | Export-Csv -Path $outputFile -NoTypeInformation -Append -Encoding UTF8
}

#Vérification de l'analyse des fichiers téléchargés et les pièces jointes
$id = "WDA5"
$statement ="(L1)Assurer que l'option 'Analyser tous les fichiers téléchargés et les pièces jointes' est réglée sur Activé "
$exist = Test-Path "HKLM\SOFTWARE\Policies\Microsoft\Windows Defender\Real-Time Protection"
if ( $exist -eq $true) {
  $value = Get-ItemProperty "HKLM\SOFTWARE\Policies\Microsoft\Windows Defender\Real-Time Protection" |Select-Object DisableIOAVProtection
  $value = $value.DisableIOAVProtection
  $complianceStatus = if ($value -eq 0) { "Conforme" } else { "Non-Conforme" }
  $complianceData = New-Object PSObject -Property @{
        "ID" = $id
        "Point de contrôle" = $statement
        "Status de conformité" = $complianceStatus
       }
       $outputFile = "./Audit_config_" + "$OSName" + "_" + $Date + ".csv"
       $complianceData | Select-Object $columnOrder | Export-Csv -Path $outputFile -NoTypeInformation -Append -Encoding UTF8
       }
else {
  $complianceStatus="Non-Applicable"
  $complianceData = New-Object PSObject -Property @{
        "ID" = $id
        "Point de contrôle" = $statement
        "Status de conformité" = $complianceStatus
       }
       $outputFile = "./Audit_config_" + "$OSName" + "_" + $Date + ".csv"
       $complianceData | Select-Object $columnOrder | Export-Csv -Path $outputFile -NoTypeInformation -Append -Encoding UTF8
}

#Vérification de Windows installer 
Write-Host "================ Audit de Windows installer ================"

#Vérification de l"installation
$id = "WIA1"
$statement ="(L1)Assurer que l'option 'Toujours installer avec des privilèges élevés' est réglée sur Désactivé "
$exist = Test-Path "HKLM:\SOFTWARE\Policies\Microsoft\Windows\Installer"
if ( $exist -eq $true) {
  $value = Get-ItemProperty "HKLM:\SOFTWARE\Policies\Microsoft\Windows\Installer" |Select-Object AlwaysInstallElevated
  $value = $value.AlwaysInstallElevated
  $complianceStatus = if ($value -eq 0) { "Conforme" } else { "Non-Conforme" }
  $complianceData = New-Object PSObject -Property @{
        "ID" = $id
        "Point de contrôle" = $statement
        "Status de conformité" = $complianceStatus
       }
       $outputFile = "./Audit_config_" + "$OSName" + "_" + $Date + ".csv"
       $complianceData | Select-Object $columnOrder | Export-Csv -Path $outputFile -NoTypeInformation -Append -Encoding UTF8
       }
else {
  $complianceStatus="Non-Applicable"
  $complianceData = New-Object PSObject -Property @{
        "ID" = $id
        "Point de contrôle" = $statement
        "Status de conformité" = $complianceStatus
       }
       $outputFile = "./Audit_config_" + "$OSName" + "_" + $Date + ".csv"
       $complianceData | Select-Object $columnOrder | Export-Csv -Path $outputFile -NoTypeInformation -Append -Encoding UTF8
}


#Vérification de contrôle des installations par l'utilisateur
$id = "WIA2"
$statement ="(L1)Assurer que l'option 'Autoriser le contrôle des installations par l'utilisateur' est réglée sur Désactivé "
$exist = Test-Path "HKLM:\SOFTWARE\Policies\Microsoft\Windows\Installer"
if ( $exist -eq $true) {
  $value = Get-ItemProperty "HKLM:\SOFTWARE\Policies\Microsoft\Windows\Installer" |Select-Object EnableUserControl
  $value = $value.EnableUserControl
  $complianceStatus = if ($value -eq 0) { "Conforme" } else { "Non-Conforme" }
  $complianceData = New-Object PSObject -Property @{
        "ID" = $id
        "Point de contrôle" = $statement
        "Status de conformité" = $complianceStatus
       }
       $outputFile = "./Audit_config_" + "$OSName" + "_" + $Date + ".csv"
       $complianceData | Select-Object $columnOrder | Export-Csv -Path $outputFile -NoTypeInformation -Append -Encoding UTF8
       }
else {
  $complianceStatus="Non-Applicable"
  $complianceData = New-Object PSObject -Property @{
        "ID" = $id
        "Point de contrôle" = $statement
        "Status de conformité" = $complianceStatus
       }
       $outputFile = "./Audit_config_" + "$OSName" + "_" + $Date + ".csv"
       $complianceData | Select-Object $columnOrder | Export-Csv -Path $outputFile -NoTypeInformation -Append -Encoding UTF8
}

#Vérification de scripts de windows installer
$id = "WIA3"
$statement ="(L1)Assurer que l'option 'Empêcher l'invite de sécurité d'Internet Explorer pour les scripts de Windows Installer' est réglée sur Désactivé "
$exist = Test-Path "HKLM:\SOFTWARE\Policies\Microsoft\Windows\Installer"
if ( $exist -eq $true) {
  $value = Get-ItemProperty "HKLM:\SOFTWARE\Policies\Microsoft\Windows\Installer" |Select-Object SafeForScripting
  $value = $value.SafeForScripting
  $complianceStatus = if ($value -eq 0) { "Conforme" } else { "Non-Conforme" }
  $complianceData = New-Object PSObject -Property @{
        "ID" = $id
        "Point de contrôle" = $statement
        "Status de conformité" = $complianceStatus
       }
       $outputFile = "./Audit_config_" + "$OSName" + "_" + $Date + ".csv"
       $complianceData | Select-Object $columnOrder | Export-Csv -Path $outputFile -NoTypeInformation -Append -Encoding UTF8
       }
else {
  $complianceStatus="Non-Applicable"
  $complianceData = New-Object PSObject -Property @{
        "ID" = $id
        "Point de contrôle" = $statement
        "Status de conformité" = $complianceStatus
       }
       $outputFile = "./Audit_config_" + "$OSName" + "_" + $Date + ".csv"
       $complianceData | Select-Object $columnOrder | Export-Csv -Path $outputFile -NoTypeInformation -Append -Encoding UTF8
}



#Vérification de Windows remote management 
Write-Host "================ Audit de Windows remote management ================"

#Vérification de l'authentification
$id = "WRMA1"
$statement ="(L1)Assurer que l'option 'Autoriser l'authentification de base' est réglée sur Désactivé "
$exist = Test-Path "HKLM:\SOFTWARE\Policies\Microsoft\Windows\WinRM\Client"
if ( $exist -eq $true) {
  $value = Get-ItemProperty "HKLM:\SOFTWARE\Policies\Microsoft\Windows\WinRM\Client" |Select-Object AllowBasic
  $value = $value.AllowBasic
  $complianceStatus = if ($value -eq 0) { "Conforme" } else { "Non-Conforme" }
  $complianceData = New-Object PSObject -Property @{
        "ID" = $id
        "Point de contrôle" = $statement
        "Status de conformité" = $complianceStatus
       }
       $outputFile = "./Audit_config_" + "$OSName" + "_" + $Date + ".csv"
       $complianceData | Select-Object $columnOrder | Export-Csv -Path $outputFile -NoTypeInformation -Append -Encoding UTF8
       }
else {
  $complianceStatus="Non-Applicable"
  $complianceData = New-Object PSObject -Property @{
        "ID" = $id
        "Point de contrôle" = $statement
        "Status de conformité" = $complianceStatus
       }
       $outputFile = "./Audit_config_" + "$OSName" + "_" + $Date + ".csv"
       $complianceData | Select-Object $columnOrder | Export-Csv -Path $outputFile -NoTypeInformation -Append -Encoding UTF8
}

#Vérification de trafic
$id = "WRMA2"
$statement ="(L1)Assurer que l'option 'Autoriser le trafic non crypté' est réglée sur Désactivé "
$exist = Test-Path "HKLM:\SOFTWARE\Policies\Microsoft\Windows\WinRM\Client"
if ( $exist -eq $true) {
  $value = Get-ItemProperty "HKLM:\SOFTWARE\Policies\Microsoft\Windows\WinRM\Client" |Select-Object AllowUnencryptedTraffic
  $value = $value.AllowUnencryptedTraffic
  $complianceStatus = if ($value -eq 0) { "Conforme" } else { "Non-Conforme" }
  $complianceData = New-Object PSObject -Property @{
        "ID" = $id
        "Point de contrôle" = $statement
        "Status de conformité" = $complianceStatus
       }
       $outputFile = "./Audit_config_" + "$OSName" + "_" + $Date + ".csv"
       $complianceData | Select-Object $columnOrder | Export-Csv -Path $outputFile -NoTypeInformation -Append -Encoding UTF8
       }
else {
  $complianceStatus="Non-Applicable"
  $complianceData = New-Object PSObject -Property @{
        "ID" = $id
        "Point de contrôle" = $statement
        "Status de conformité" = $complianceStatus
       }
       $outputFile = "./Audit_config_" + "$OSName" + "_" + $Date + ".csv"
       $complianceData | Select-Object $columnOrder | Export-Csv -Path $outputFile -NoTypeInformation -Append -Encoding UTF8
}

#Vérification de L'authentification Digest
$id = "WRMA3"
$statement ="(L1)Assurer que l'option 'Ne pas autoriser l'authentification Digest' est réglée sur Activé "
$exist = Test-Path "HKLM:\SOFTWARE\Policies\Microsoft\Windows\WinRM\Client"
if ( $exist -eq $true) {
  $value = Get-ItemProperty "HKLM:\SOFTWARE\Policies\Microsoft\Windows\WinRM\Client" |Select-Object AllowDigest
  $value = $value.AllowDigest
  $complianceStatus = if ($value -eq 0) { "Conforme" } else { "Non-Conforme" }
  $complianceData = New-Object PSObject -Property @{
        "ID" = $id
        "Point de contrôle" = $statement
        "Status de conformité" = $complianceStatus
       }
       $outputFile = "./Audit_config_" + "$OSName" + "_" + $Date + ".csv"
       $complianceData | Select-Object $columnOrder | Export-Csv -Path $outputFile -NoTypeInformation -Append -Encoding UTF8
       }
else {
  $complianceStatus="Non-Applicable"
  $complianceData = New-Object PSObject -Property @{
        "ID" = $id
        "Point de contrôle" = $statement
        "Status de conformité" = $complianceStatus
       }
       $outputFile = "./Audit_config_" + "$OSName" + "_" + $Date + ".csv"
       $complianceData | Select-Object $columnOrder | Export-Csv -Path $outputFile -NoTypeInformation -Append -Encoding UTF8
}

#Vérification de stockage des informations d'identification RunAs
$id = "WRMA4"
$statement ="(L1)Assurer que l'option 'Interdire à WinRM de stocker les informations d'identification RunAs' est réglée sur Activé "
$exist = Test-Path "HKLM:\SOFTWARE\Policies\Microsoft\Windows\WinRM\Service"
if ( $exist -eq $true) {
  $value = Get-ItemProperty "HKLM:\SOFTWARE\Policies\Microsoft\Windows\WinRM\Service" |Select-Object DisableRunAs
  $value = $value.DisableRunAs
  $complianceStatus = if ($value -eq 1) { "Conforme" } else { "Non-Conforme" }
  $complianceData = New-Object PSObject -Property @{
        "ID" = $id
        "Point de contrôle" = $statement
        "Status de conformité" = $complianceStatus
       }
       $outputFile = "./Audit_config_" + "$OSName" + "_" + $Date + ".csv"
       $complianceData | Select-Object $columnOrder | Export-Csv -Path $outputFile -NoTypeInformation -Append -Encoding UTF8
       }
else {
  $complianceStatus="Non-Applicable"
  $complianceData = New-Object PSObject -Property @{
        "ID" = $id
        "Point de contrôle" = $statement
        "Status de conformité" = $complianceStatus
       }
       $outputFile = "./Audit_config_" + "$OSName" + "_" + $Date + ".csv"
       $complianceData | Select-Object $columnOrder | Export-Csv -Path $outputFile -NoTypeInformation -Append -Encoding UTF8
}


#Vérification de Windows remote shell 
Write-Host "================ Audit de Windows remote shell ================"

#Vérification de l'accès au shell à distance
$id = "WRSA1"
$statement ="(L1)Assurer que l'option 'Autoriser l'accès au shell à distance' est réglée sur Désactivé "
$exist = Test-Path "HKLM:\SOFTWARE\Policies\Microsoft\Windows\WinRM\Service\WinRS"
if ( $exist -eq $true) {
  $value = Get-ItemProperty "HKLM:\SOFTWARE\Policies\Microsoft\Windows\WinRM\Service\WinRS" |Select-Object AllowRemoteShellAccess
  $value = $value.AllowRemoteShellAccess
  $complianceStatus = if ($value -eq 0) { "Conforme" } else { "Non-Conforme" }
  $complianceData = New-Object PSObject -Property @{
        "ID" = $id
        "Point de contrôle" = $statement
        "Status de conformité" = $complianceStatus
       }
       $outputFile = "./Audit_config_" + "$OSName" + "_" + $Date + ".csv"
       $complianceData | Select-Object $columnOrder | Export-Csv -Path $outputFile -NoTypeInformation -Append -Encoding UTF8
       }
else {
  $complianceStatus="Non-Applicable"
  $complianceData = New-Object PSObject -Property @{
        "ID" = $id
        "Point de contrôle" = $statement
        "Status de conformité" = $complianceStatus
       }
       $outputFile = "./Audit_config_" + "$OSName" + "_" + $Date + ".csv"
       $complianceData | Select-Object $columnOrder | Export-Csv -Path $outputFile -NoTypeInformation -Append -Encoding UTF8
}

#Vérification de Windows update 
Write-Host "================ Audit de Windows update ================"

#Vérification des mises à jour automatiques
$id = "WUA1"
$statement ="(L1)Assurer que l'option 'Configurer les mises à jour automatiques' est réglée sur Activé "
$exist = Test-Path "HKLM:\SOFTWARE\Policies\Microsoft\Windows\WindowsUpdate\AU"
if ( $exist -eq $true) {
  $value = Get-ItemProperty "HKLM:\SOFTWARE\Policies\Microsoft\Windows\WindowsUpdate\AU" |Select-Object NoAutoUpdate
  $value = $value.NoAutoUpdate
  $complianceStatus = if ($value -eq 0) { "Conforme" } else { "Non-Conforme" }
  $complianceData = New-Object PSObject -Property @{
        "ID" = $id
        "Point de contrôle" = $statement
        "Status de conformité" = $complianceStatus
       }
       $outputFile = "./Audit_config_" + "$OSName" + "_" + $Date + ".csv"
       $complianceData | Select-Object $columnOrder | Export-Csv -Path $outputFile -NoTypeInformation -Append -Encoding UTF8
       }
else {
  $complianceStatus="Non-Applicable"
  $complianceData = New-Object PSObject -Property @{
        "ID" = $id
        "Point de contrôle" = $statement
        "Status de conformité" = $complianceStatus
       }
       $outputFile = "./Audit_config_" + "$OSName" + "_" + $Date + ".csv"
       $complianceData | Select-Object $columnOrder | Export-Csv -Path $outputFile -NoTypeInformation -Append -Encoding UTF8
}


#Vérification de Gestionnaire des pièces jointes 
Write-Host "================ Audit de Gestionnaire des pièces jointes ================"

#Vérification de l'ouverture des pièces jointes
$id = "AMA1"
$statement ="(L1)Assurer que l'option 'Notifier les programmes antivirus lors de l'ouverture des pièces jointes' est réglée sur Activé "
$exist = Test-Path "HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\Attachments"
if ( $exist -eq $true) {
  $value = Get-ItemProperty "HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\Attachments" |Select-Object ScanWithAntiVirus
  $value = $value.ScanWithAntiVirus
  $complianceStatus = if ($value -eq 1) { "Conforme" } else { "Non-Conforme" }
  $complianceData = New-Object PSObject -Property @{
        "ID" = $id
        "Point de contrôle" = $statement
        "Status de conformité" = $complianceStatus
       }
       $outputFile = "./Audit_config_" + "$OSName" + "_" + $Date + ".csv"
       $complianceData | Select-Object $columnOrder | Export-Csv -Path $outputFile -NoTypeInformation -Append -Encoding UTF8
       }
else {
  $complianceStatus="Non-Applicable"
  $complianceData = New-Object PSObject -Property @{
        "ID" = $id
        "Point de contrôle" = $statement
        "Status de conformité" = $complianceStatus
       }
       $outputFile = "./Audit_config_" + "$OSName" + "_" + $Date + ".csv"
       $complianceData | Select-Object $columnOrder | Export-Csv -Path $outputFile -NoTypeInformation -Append -Encoding UTF8
}

Write-Host "Les résultats sont sauvegardés dans $outputFile" -ForegroundColor Green
Write-Host "Fin d'audit"